// ============================================================
//  RETROBOX v3.8  —  ESP32 Multi-Game Handheld Console
//  Author:  VOID (https://github.com/VOID016)
//  License: MIT
//  Board:   ESP32 DevKit V1
//  Display: SSD1306 128×64 OLED (I2C)
// ============================================================
//
//  WHAT'S NEW IN 3.8  —  SAVE & CONTINUE
//  ──────────────────────────────────────────────────────────
//  * CONTINUE / NEW GAME screen before difficulty select
//    (shown only when that game actually has a save)
//  * Pause -> B now asks SAVE PROGRESS?  A = yes, B = no
//  * One save slot per game, overwritten on every save
//  * Games opt in with 3 functions — see SAVE_SYSTEM.md
//  * High scores are no longer written mid-run (see CHANGELOG)
//
//  Every line touched by the save feature is marked  // <SAVE>
//
//  QUICK START
//  ──────────────────────────────────────────────────────────
//  1. Install libraries (see README.md)
//  2. Open games_config.h to enable/disable games
//  3. Flash to your ESP32
//  4. Plug in, play
//
//  ADDING A CUSTOM GAME → see ADDING_A_GAME.md
//  SAVE SYSTEM          → see SAVE_SYSTEM.md
//  WIRING REFERENCE     → see WIRING_DIAGRAM.md
// ============================================================
// ============================================================
//  PIN ASSIGNMENTS:
//   GPIO21 → OLED SDA        GPIO22 → OLED SCL
//   GPIO34 → Joystick VRx    GPIO35 → Joystick VRy
//   GPIO25 → Joystick SW     GPIO14 → Button A (fire/confirm)
//   GPIO27 → Button B (back/special)
//   GPIO13 → Button START    GPIO26 → Buzzer (direct, 3.3V)
// ============================================================


#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Preferences.h>
#include "retrobox_types.h"
#include "save_system.h"        // <SAVE> universal save slot engine
#include <WiFi.h>
#include "esp_wifi.h"
#include <math.h>

// ── Game modules (enable/disable in games_config.h) ──────────
#include "games_config.h"

#ifdef ENABLE_RACER
  #include "game_racer.h"
#endif
#ifdef ENABLE_TETRIS
  #include "game_tetris.h"
#endif
#ifdef ENABLE_SNAKE
  #include "game_snake.h"
#endif
#ifdef ENABLE_ARKANOID
  #include "game_arkanoid.h"
#endif
#ifdef ENABLE_VSHOOTER
  #include "game_vshooter.h"
#endif
#ifdef ENABLE_DUNGEON
  #include "game_dungeon.h"
#endif
#ifdef ENABLE_DOOM
  #include "game_doom.h"
#endif
#ifdef ENABLE_MARIO
  #include "game_mario.h"
#endif

// ── Save hooks — struct must live here, not next to gameSaveHooks() ──  <SAVE>
// Arduino auto-generates a forward declaration for every function in this
// file and inserts them all in a block right after the last #include —
// BEFORE any type defined later in the file exists yet. gameSaveHooks()
// returns SaveHooks, so the struct has to be visible by this point, or the
// auto-generated prototype fails with "'SaveHooks' does not name a type".
// (Every other custom type below — GameID, TutLine, MarioTutPage — is only
// ever used inside a function body or as a variable's type, never as a
// function's own return/parameter type, so none of those need to move.)
struct SaveHooks {
  size_t      (*capture)(void* out, size_t max);
  bool        (*restore)(const void* in, size_t len);
  void        (*label)  (char* out, size_t n);
  const char*   tag;
};

// ── Hardware constants ────────────────────────────────────────
#define SCREEN_WIDTH   128
#define SCREEN_HEIGHT   64
#define OLED_ADDR      0x3C
#define JOY_X_PIN       34
#define JOY_Y_PIN       35
#define JOY_SW_PIN      25
#define BTN_A_PIN       14
#define BTN_B_PIN       27
#define BTN_START_PIN   13
#define BUZZER_PIN      26
#define ONBOARD_LED      2

// ── Musical notes ─────────────────────────────────────────────
#define NOTE_C4   262
#define NOTE_D4   294
#define NOTE_E4   330
#define NOTE_F4   349
#define NOTE_G4   392
#define NOTE_A4   440
#define NOTE_B4   494
#define NOTE_C5   523
#define NOTE_G3   196
#define NOTE_A3   220
#define NOTE_REST   0

// ── Global objects ────────────────────────────────────────────
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
Preferences       prefs;

// ── Orientation ───────────────────────────────────────────────
enum Orientation { ORI_LANDSCAPE = 0, ORI_PORTRAIT = 1, ORI_LANDSCAPE_FLIP = 2, ORI_PORTRAIT_FLIP = 3 };
Orientation currentOri = ORI_LANDSCAPE;

int PLAY_W = 128;
int PLAY_H = 64;

void applyOrientation() {
  switch (currentOri) {
    case ORI_LANDSCAPE:      display.setRotation(0); PLAY_W = 128; PLAY_H = 64;  break;
    case ORI_PORTRAIT:       display.setRotation(1); PLAY_W = 64;  PLAY_H = 128; break;
    case ORI_LANDSCAPE_FLIP: display.setRotation(2); PLAY_W = 128; PLAY_H = 64;  break;
    case ORI_PORTRAIT_FLIP:  display.setRotation(3); PLAY_W = 64;  PLAY_H = 128; break;
  }
}

void resetOrientation() {
  display.setRotation(0);
  PLAY_W = 128;
  PLAY_H = 64;
}

// ── Game list ─────────────────────────────────────────────────
enum GameID {
  GAME_RACER = 0,
  GAME_TETRIS,
  GAME_SNAKE,
  GAME_ARKANOID,
  GAME_VSHOOTER,
  GAME_DUNGEON,
  GAME_DOOM,
  GAME_MARIO,
  GAME_COUNT
};
const char* GAME_NAMES[GAME_COUNT] = {
  "RACER", "TETRIS", "SNAKE", "ARKANOID", "V-SHOOTER", "DUNGEON", "DOOM", "MARIO"
};
// Turns "menu shows a blank game name" into a compile error.
static_assert(sizeof(GAME_NAMES) / sizeof(GAME_NAMES[0]) == GAME_COUNT,
              "GAME_NAMES needs exactly one entry per GameID");

// ── Difficulty ────────────────────────────────────────────────

const char* DIFF_NAMES[] = { "EASY", "MEDIUM", "HARD" };
Difficulty currentDiff = DIFF_MEDIUM;

// ── Top-level state machine ───────────────────────────────────
enum AppState {
  STATE_SPLASH,
  STATE_GAME_SELECT,
  STATE_TUTORIAL,
  STATE_SAVE_SELECT,        // <SAVE>  CONTINUE / NEW GAME
  STATE_DIFFICULTY_SELECT,
  STATE_ORI_SELECT,
  STATE_PLAYING,
  STATE_PAUSED,
  STATE_SAVE_PROMPT,        // <SAVE>  "SAVE PROGRESS?" on exit
  STATE_GAME_OVER,
  STATE_DEV_MENU
};
AppState appState = STATE_SPLASH;
int      selectedGame  = 0;
int      devMenuPage   = 0;

// ── Save-system plumbing ──────────────────────────────────────  <SAVE>
bool continueFromSave = false;   // chosen on the CONTINUE / NEW GAME screen
int  saveMenuChoice   = 0;       // 0 = CONTINUE, 1 = NEW GAME
bool gameCanSave();              // forward decls — drawPause() uses these
bool gameSaveNow();

// ── Timing ────────────────────────────────────────────────────
unsigned long splashStart    = 0;
unsigned long lastFrameTime  = 0;
unsigned long gameOverEnteredAt = 0;


// ── Score storage ─────────────────────────────────────────────
int highScores[GAME_COUNT][3];  // [game][difficulty]
int joystickSensitivity = 7;     // 1 = least sensitive, 10 = most sensitive

// ── Joystick helpers ─────────────────────────────────────────
int  joyX()     { return analogRead(JOY_X_PIN); }
int  joyY()     { return analogRead(JOY_Y_PIN); }
// Higher joystickSensitivity = lighter touch registers movement (smaller
// deadzone) AND faster movement once triggered (bigger step). These two
// used to pull in OPPOSITE directions: offset grew WITH sensitivity, so
// level 10 needed the biggest push of anyone before ANYTHING registered at
// all — backwards for a setting called "sensitivity," and exactly why two
// levels could feel confusingly similar (a bigger required push cancelling
// out a bigger step) depending on how hard you were actually pushing the
// stick. Both now move the same direction as the number: turn it up, the
// stick reacts to less push and moves faster once it does.
int  joyOffset() { return constrain(300 + (11 - joystickSensitivity) * 63, 363, 930); }
int  joyLow()    { return 2048 - joyOffset(); }
int  joyHigh()   { return 2048 + joyOffset(); }
bool joyBelow(int v) { return v < joyLow(); }
bool joyAbove(int v) { return v > joyHigh(); }
// 5 distinct speeds spread evenly across the 10 levels — the old version had
// only 3 buckets total (levels 8, 9 and 10 were literally identical), which
// on its own made the top third of the scale feel like one setting. Level 1
// and level 8 are now 1 vs 4, a clear difference in every game that reads
// this (Arkanoid's paddle, Racer's steering, V-Shooter's ship, DOOM's
// move/turn speed).
int  joyMoveStep()   { return 1 + (joystickSensitivity - 1) / 2; }
bool joyLeft() {
  if (currentOri == ORI_PORTRAIT)       return joyBelow(joyY());
  if (currentOri == ORI_LANDSCAPE_FLIP) return joyAbove(joyX());
  if (currentOri == ORI_PORTRAIT_FLIP)  return joyAbove(joyY());
  return joyBelow(joyX());
}
bool joyRight() {
  if (currentOri == ORI_PORTRAIT)       return joyAbove(joyY());
  if (currentOri == ORI_LANDSCAPE_FLIP) return joyBelow(joyX());
  if (currentOri == ORI_PORTRAIT_FLIP)  return joyBelow(joyY());
  return joyAbove(joyX());
}
bool joyUp() {
  if (currentOri == ORI_PORTRAIT)       return joyAbove(joyX());
  if (currentOri == ORI_LANDSCAPE_FLIP) return joyAbove(joyY());
  if (currentOri == ORI_PORTRAIT_FLIP)  return joyBelow(joyX());
  return joyBelow(joyY());
}
bool joyDown() {
  if (currentOri == ORI_PORTRAIT)       return joyBelow(joyX());
  if (currentOri == ORI_LANDSCAPE_FLIP) return joyBelow(joyY());
  if (currentOri == ORI_PORTRAIT_FLIP)  return joyAbove(joyX());
  return joyAbove(joyY());
}
bool joyMenuUp()   { return joyBelow(joyY()); }
bool joyMenuDown() { return joyAbove(joyY()); }
bool joyMenuLeft() { return joyBelow(joyX()); }
bool joyMenuRight(){ return joyAbove(joyX()); }

// ── Interrupt-driven jump button latch ────────────────────────
volatile bool btnA_isr_fired = false;
volatile unsigned long btnA_isr_lastMs = 0;
void IRAM_ATTR btnA_ISR() {
  unsigned long now = millis();
  if (now - btnA_isr_lastMs > 30) { btnA_isr_fired = true; btnA_isr_lastMs = now; }
}

// ── Button state (latched edge detector) ─────────────────────
Button btnA     = {BTN_A_PIN,    true, false, false};
Button btnB     = {BTN_B_PIN,    true, false, false};
Button btnStart = {BTN_START_PIN,true, false, false};
Button btnJoySW = {JOY_SW_PIN,   true, false, false};

void readButtons() {
  if (btnA_isr_fired) {
    btnA.pressed     = true;
    btnA_isr_fired   = false;
  }
  auto update = [](Button& b) {
    bool cur = (digitalRead(b.pin) == LOW);
    if (cur && !b.lastState) b.pressed = true;
    b.held      = cur;
    b.lastState = cur;
  };
  update(btnA);
  update(btnB);
  update(btnStart);
  update(btnJoySW);
}

void clearButtons() {
  btnA.pressed     = false;
  btnB.pressed     = false;
  btnStart.pressed = false;
  btnJoySW.pressed = false;
}

// ── Dev mode: B + START held 1.5 seconds ─────────────────────
unsigned long devHoldStart = 0;
bool devHolding = false;
void sfxLevelUp();

void checkDevHold() {
  if (appState != STATE_GAME_SELECT) { devHolding = false; return; }
  bool both = btnB.held && btnStart.held;
  if (both) {
    if (!devHolding) { devHolding = true; devHoldStart = millis(); }
    else if (millis() - devHoldStart > 1500) {
      devHolding = false;
      devMenuPage = 0;
      appState = STATE_DEV_MENU;
      sfxLevelUp();
    }
  } else {
    devHolding = false;
  }
}

// ── Buzzer (LEDC PWM) ─────────────────────────────────────────
void sfxBeep()     { ledcWriteTone(0, NOTE_C5); delay(50);  ledcWriteTone(0, 0); }
void sfxConfirm()  { ledcWriteTone(0, NOTE_E4); delay(40);  ledcWriteTone(0, NOTE_G4); delay(60); ledcWriteTone(0, 0); }
void sfxBack()     { ledcWriteTone(0, NOTE_G4); delay(40);  ledcWriteTone(0, NOTE_C4); delay(60); ledcWriteTone(0, 0); }
void sfxShoot()    { ledcWriteTone(0, NOTE_A4); delay(30);  ledcWriteTone(0, 0); }
void sfxExplode()  { ledcWriteTone(0, NOTE_G3); delay(80);  ledcWriteTone(0, NOTE_A3); delay(60); ledcWriteTone(0, 0); }
void sfxGameOver() {
  int notes[] = {NOTE_C4, NOTE_B4, NOTE_A4, NOTE_G3};
  for (int n : notes) { ledcWriteTone(0, n); delay(120); }
  ledcWriteTone(0, 0);
}
void sfxLevelUp()  {
  int notes[] = {NOTE_C4, NOTE_E4, NOTE_G4, NOTE_C5};
  for (int n : notes) { ledcWriteTone(0, n); delay(80); }
  ledcWriteTone(0, 0);
}
void sfxMenu()  { ledcWriteTone(0, NOTE_D4); delay(35); ledcWriteTone(0, 0); }
void sfxPower() {
  int notes[] = {NOTE_C4, NOTE_E4, NOTE_G4, NOTE_C5, NOTE_G4, NOTE_E4, NOTE_C4};
  int lens[]  = {80, 80, 80, 160, 60, 60, 120};
  for (int i = 0; i < 7; i++) { ledcWriteTone(0, notes[i]); delay(lens[i]); }
  ledcWriteTone(0, 0);
}
void sfxHit()   { ledcWriteTone(0, 150); delay(40); ledcWriteTone(0, 0); }

// ── NVS helpers ───────────────────────────────────────────────
void loadAllScores() {
  prefs.begin("rb24", true);
  for (int g = 0; g < GAME_COUNT; g++)
    for (int d = 0; d < 3; d++) {
      char k[12]; snprintf(k, sizeof(k), "g%dd%d", g, d);
      int v = prefs.getInt(k, 0);
      highScores[g][d] = (v < 0 || v > 9999999) ? 0 : v;
    }
  prefs.end();
}
void loadSettings() {
  prefs.begin("rb24", true);
  joystickSensitivity = prefs.getInt("joySens", 7);
  prefs.end();
  joystickSensitivity = constrain(joystickSensitivity, 1, 10);
}
void saveJoystickSensitivity() {
  joystickSensitivity = constrain(joystickSensitivity, 1, 10);
  prefs.begin("rb24", false);
  prefs.putInt("joySens", joystickSensitivity);
  prefs.end();
}
void saveScore(int game, int diff, int score) {
  if (game < 0 || game >= GAME_COUNT || diff < 0 || diff > 2) return;
  if (score <= highScores[game][diff]) return;
  highScores[game][diff] = score;
  prefs.begin("rb24", false);
  char k[12]; snprintf(k, sizeof(k), "g%dd%d", game, diff);
  prefs.putInt(k, score);
  prefs.end();
}
void factoryReset() {
  prefs.begin("rb24", false);
  prefs.clear();
  prefs.end();
  SaveSystem::wipeAll();            // <SAVE> wipe every saved game too
  for (int g = 0; g < GAME_COUNT; g++)
    for (int d = 0; d < 3; d++)
      highScores[g][d] = 0;
  joystickSensitivity = 7;
}

// ── I2C bus recovery ─────────────────────────────────────────
void recoverI2CBus() {
  pinMode(21, OUTPUT); pinMode(22, OUTPUT);
  digitalWrite(21, HIGH); digitalWrite(22, HIGH);
  for (int i = 0; i < 9; i++) {
    digitalWrite(22, LOW); delayMicroseconds(5);
    digitalWrite(22, HIGH); delayMicroseconds(5);
  }
  digitalWrite(21, LOW); delayMicroseconds(5);
  digitalWrite(22, HIGH); delayMicroseconds(5);
  digitalWrite(21, HIGH); delayMicroseconds(5);
  Wire.begin();
}

// ============================================================
//  DRAW UTILITIES
// ============================================================
void drawCenteredText(int y, const char* str, int size =1) {
  display.setTextSize(size);
  int16_t x1, y1; uint16_t w, h;
  display.getTextBounds(str, 0, y, &x1, &y1, &w, &h);
  display.setCursor((PLAY_W - (int)w) / 2, y);
  display.print(str);
}
void drawBorderBox() {
  display.drawRect(0, 0, PLAY_W, PLAY_H, SSD1306_WHITE);
}

static int starX[24], starY[24];
static bool starsInited = false;
void initStars() {
  if (starsInited) return;
  for (int i = 0; i < 24; i++) {
    starX[i] = random(0, SCREEN_WIDTH);
    starY[i] = random(0, SCREEN_HEIGHT);
  }
  starsInited = true;
}
void scrollStarsH(int speed = 1) {
  for (int i = 0; i < 24; i++) {
    display.drawPixel(starX[i], starY[i], SSD1306_WHITE);
    starX[i] -= speed;
    if (starX[i] < 0) { starX[i] = SCREEN_WIDTH - 1; starY[i] = random(0, SCREEN_HEIGHT); }
  }
}
void scrollStarsV(int* sx, int* sy, int n, int speed = 1) {
  for (int i = 0; i < n; i++) {
    display.drawPixel(sx[i], sy[i], SSD1306_WHITE);
    sy[i] += speed;
    if (sy[i] >= PLAY_H) { sy[i] = 0; sx[i] = random(0, PLAY_W); }
  }
}

void drawShip(int x, int y) {
  display.fillRect(x+3, y,   2, 2, SSD1306_WHITE);
  display.fillRect(x+1, y+2, 6, 2, SSD1306_WHITE);
  display.fillRect(x,   y+4, 8, 1, SSD1306_WHITE);
  display.drawPixel(x+3, y-1, SSD1306_WHITE);
}

// Short blocking toast — only ever used from menus, never mid-frame.  <SAVE>
void flashMessage(const char* line1, const char* line2, int ms) {
  resetOrientation();
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.drawRect(0, 0, 128, 64, SSD1306_WHITE);
  drawCenteredText(20, line1, 1);
  drawCenteredText(34, line2, 2);
  display.display();
  delay(ms);
}

// ============================================================
//  GAME DISPATCH
// ============================================================
// Every case is wrapped in the game's #ifdef, so commenting a game
// out of games_config.h no longer breaks the build. A game that is
// not compiled in simply has no cases anywhere, and gameEnabled()
// hides it from the menu.

bool gameEnabled(int g) {
  switch (g) {
#ifdef ENABLE_RACER
    case GAME_RACER:    return true;
#endif
#ifdef ENABLE_TETRIS
    case GAME_TETRIS:   return true;
#endif
#ifdef ENABLE_SNAKE
    case GAME_SNAKE:    return true;
#endif
#ifdef ENABLE_ARKANOID
    case GAME_ARKANOID: return true;
#endif
#ifdef ENABLE_VSHOOTER
    case GAME_VSHOOTER: return true;
#endif
#ifdef ENABLE_DUNGEON
    case GAME_DUNGEON:  return true;
#endif
#ifdef ENABLE_DOOM
    case GAME_DOOM:     return true;
#endif
#ifdef ENABLE_MARIO
    case GAME_MARIO:    return true;
#endif
    default: break;
  }
  return false;
}

int enabledGameCount() {
  int n = 0;
  for (int g = 0; g < GAME_COUNT; g++) if (gameEnabled(g)) n++;
  return n;
}

// Next enabled game in `dir` (+1 / -1), or the current one if there is
// nothing else. Never loops forever, even with zero games compiled in.
int nextEnabledGame(int from, int dir) {
  for (int step = 1; step <= GAME_COUNT; step++) {
    int g = from + dir * step;
    if (g < 0 || g >= GAME_COUNT) break;
    if (gameEnabled(g)) return g;
  }
  return from;
}

int firstEnabledGame() {
  for (int g = 0; g < GAME_COUNT; g++) if (gameEnabled(g)) return g;
  return 0;
}

// ── Save hooks ────────────────────────────────────────────────  <SAVE>
// ONE line per game. Explicit `case` labels mean reordering the GameID
// enum can never mis-assign a game's save functions. A game that omits
// these three functions is simply absent here and has no save — the
// CONTINUE screen is skipped and pause->B exits straight to the menu.
// (SaveHooks itself is defined up near the includes — see the comment there.)
SaveHooks gameSaveHooks(int g) {
  switch (g) {
#ifdef ENABLE_RACER
    case GAME_RACER:    return { RacerGame::captureState,    RacerGame::restoreState,    RacerGame::saveLabel,    RacerGame::SAVE_TAG };
#endif
#ifdef ENABLE_TETRIS
    case GAME_TETRIS:   return { TetrisGame::captureState,   TetrisGame::restoreState,   TetrisGame::saveLabel,   TetrisGame::SAVE_TAG };
#endif
#ifdef ENABLE_SNAKE
    case GAME_SNAKE:    return { SnakeGame::captureState,    SnakeGame::restoreState,    SnakeGame::saveLabel,    SnakeGame::SAVE_TAG };
#endif
#ifdef ENABLE_ARKANOID
    case GAME_ARKANOID: return { ArkanoidGame::captureState, ArkanoidGame::restoreState, ArkanoidGame::saveLabel, ArkanoidGame::SAVE_TAG };
#endif
#ifdef ENABLE_VSHOOTER
    case GAME_VSHOOTER: return { VShooterGame::captureState, VShooterGame::restoreState, VShooterGame::saveLabel, VShooterGame::SAVE_TAG };
#endif
#ifdef ENABLE_DUNGEON
    case GAME_DUNGEON:  return { DungeonGame::captureState,  DungeonGame::restoreState,  DungeonGame::saveLabel,  DungeonGame::SAVE_TAG };
#endif
#ifdef ENABLE_DOOM
    case GAME_DOOM:     return { DoomGame::captureState,     DoomGame::restoreState,     DoomGame::saveLabel,     DoomGame::SAVE_TAG };
#endif
#ifdef ENABLE_MARIO
    case GAME_MARIO:    return { MarioGame::captureState,    MarioGame::restoreState,    MarioGame::saveLabel,    MarioGame::SAVE_TAG };
#endif
    default: break;
  }
  return { nullptr, nullptr, nullptr, nullptr };
}

bool gameCanSave() {
  SaveHooks h = gameSaveHooks(selectedGame);
  return h.capture && h.restore && h.label && h.tag;
}

// Does a usable save exist for the selected game?
bool gameHasSave() {
  SaveHooks h = gameSaveHooks(selectedGame);
  if (!h.tag) return false;
  return SaveSystem::exists(selectedGame, h.tag);
}

// Snapshot the live game state and commit it. Called the instant the
// player confirms, so the save is never stale.
bool gameSaveNow() {
  SaveHooks h = gameSaveHooks(selectedGame);
  if (!h.capture || !h.label || !h.tag) return false;

  uint8_t buf[RB_SAVE_MAXBLOB];
  char    lbl[RB_SAVE_LABELLEN];
  lbl[0] = '\0';
  size_t n = h.capture(buf, sizeof(buf));
  if (n == 0) return false;
  h.label(lbl, sizeof(lbl));
  return SaveSystem::save(selectedGame, h.tag, (uint8_t)currentDiff,
                          (uint8_t)currentOri, buf, n, lbl);
}

// resume = true -> pull the slot back in; false -> fresh run.
// A missing, corrupt, foreign or wrong-geometry slot silently falls
// through to a fresh run rather than loading a broken board.
void gameInit(bool resume) {
  if (selectedGame == GAME_DOOM || selectedGame == GAME_MARIO) {
    if (currentOri == ORI_PORTRAIT)      currentOri = ORI_LANDSCAPE;
    if (currentOri == ORI_PORTRAIT_FLIP) currentOri = ORI_LANDSCAPE_FLIP;
    applyOrientation();
  }

  if (resume) {
    SaveHooks h = gameSaveHooks(selectedGame);
    if (h.restore && h.tag) {
      uint8_t buf[RB_SAVE_MAXBLOB];
      size_t n = SaveSystem::load(selectedGame, h.tag, nullptr, nullptr,
                                  buf, sizeof(buf));
      if (n && h.restore(buf, n)) return;
    }
  }

  switch (selectedGame) {
#ifdef ENABLE_RACER
    case GAME_RACER:    RacerGame::init();    break;
#endif
#ifdef ENABLE_TETRIS
    case GAME_TETRIS:   TetrisGame::init();   break;
#endif
#ifdef ENABLE_SNAKE
    case GAME_SNAKE:    SnakeGame::init();    break;
#endif
#ifdef ENABLE_ARKANOID
    case GAME_ARKANOID: ArkanoidGame::init(); break;
#endif
#ifdef ENABLE_VSHOOTER
    case GAME_VSHOOTER: VShooterGame::init(); break;
#endif
#ifdef ENABLE_DUNGEON
    case GAME_DUNGEON:  DungeonGame::init();  break;
#endif
#ifdef ENABLE_DOOM
    case GAME_DOOM:     DoomGame::init();     break;
#endif
#ifdef ENABLE_MARIO
    case GAME_MARIO:    MarioGame::initNew(); break;
#endif
    default: break;
  }
}

void gameUpdate() {
  switch (selectedGame) {
#ifdef ENABLE_RACER
    case GAME_RACER:    RacerGame::update();    break;
#endif
#ifdef ENABLE_TETRIS
    case GAME_TETRIS:   TetrisGame::update();   break;
#endif
#ifdef ENABLE_SNAKE
    case GAME_SNAKE:    SnakeGame::update();    break;
#endif
#ifdef ENABLE_ARKANOID
    case GAME_ARKANOID: ArkanoidGame::update(); break;
#endif
#ifdef ENABLE_VSHOOTER
    case GAME_VSHOOTER: VShooterGame::update(); break;
#endif
#ifdef ENABLE_DUNGEON
    case GAME_DUNGEON:  DungeonGame::update();  break;
#endif
#ifdef ENABLE_DOOM
    case GAME_DOOM:     DoomGame::update();     break;
#endif
#ifdef ENABLE_MARIO
    case GAME_MARIO:    MarioGame::update();    break;
#endif
    default: break;
  }
}
void gameDraw() {
  switch (selectedGame) {
#ifdef ENABLE_RACER
    case GAME_RACER:    RacerGame::draw();    break;
#endif
#ifdef ENABLE_TETRIS
    case GAME_TETRIS:   TetrisGame::draw();   break;
#endif
#ifdef ENABLE_SNAKE
    case GAME_SNAKE:    SnakeGame::draw();    break;
#endif
#ifdef ENABLE_ARKANOID
    case GAME_ARKANOID: ArkanoidGame::draw(); break;
#endif
#ifdef ENABLE_VSHOOTER
    case GAME_VSHOOTER: VShooterGame::draw(); break;
#endif
#ifdef ENABLE_DUNGEON
    case GAME_DUNGEON:  DungeonGame::draw();  break;
#endif
#ifdef ENABLE_DOOM
    case GAME_DOOM:     DoomGame::draw();     break;
#endif
#ifdef ENABLE_MARIO
    case GAME_MARIO:    MarioGame::draw();    break;
#endif
    default: break;
  }
}
bool gameIsOver() {
  switch (selectedGame) {
#ifdef ENABLE_RACER
    case GAME_RACER:    return RacerGame::isOver();
#endif
#ifdef ENABLE_TETRIS
    case GAME_TETRIS:   return TetrisGame::isOver();
#endif
#ifdef ENABLE_SNAKE
    case GAME_SNAKE:    return SnakeGame::isOver();
#endif
#ifdef ENABLE_ARKANOID
    case GAME_ARKANOID: return ArkanoidGame::isOver();
#endif
#ifdef ENABLE_VSHOOTER
    case GAME_VSHOOTER: return VShooterGame::isOver();
#endif
#ifdef ENABLE_DUNGEON
    case GAME_DUNGEON:  return DungeonGame::isOver();
#endif
#ifdef ENABLE_DOOM
    case GAME_DOOM:     return DoomGame::isOver();
#endif
#ifdef ENABLE_MARIO
    case GAME_MARIO:    return MarioGame::isOver();
#endif
    default: break;
  }
  // Fail CLOSED. An unregistered or disabled game ends instantly instead
  // of leaving the console frozen in STATE_PLAYING forever.
  return true;
}
int gameGetScore() {
  switch (selectedGame) {
#ifdef ENABLE_RACER
    case GAME_RACER:    return RacerGame::getScore();
#endif
#ifdef ENABLE_TETRIS
    case GAME_TETRIS:   return TetrisGame::getScore();
#endif
#ifdef ENABLE_SNAKE
    case GAME_SNAKE:    return SnakeGame::getScore();
#endif
#ifdef ENABLE_ARKANOID
    case GAME_ARKANOID: return ArkanoidGame::getScore();
#endif
#ifdef ENABLE_VSHOOTER
    case GAME_VSHOOTER: return VShooterGame::getScore();
#endif
#ifdef ENABLE_DUNGEON
    case GAME_DUNGEON:  return DungeonGame::getScore();
#endif
#ifdef ENABLE_DOOM
    case GAME_DOOM:     return DoomGame::getScore();
#endif
#ifdef ENABLE_MARIO
    case GAME_MARIO:    return MarioGame::getScore();
#endif
    default: break;
  }
  return 0;
}
bool gameIsNewRecord() {
  switch (selectedGame) {
#ifdef ENABLE_RACER
    case GAME_RACER:    return RacerGame::isNewRecord();
#endif
#ifdef ENABLE_TETRIS
    case GAME_TETRIS:   return TetrisGame::isNewRecord();
#endif
#ifdef ENABLE_SNAKE
    case GAME_SNAKE:    return SnakeGame::isNewRecord();
#endif
#ifdef ENABLE_ARKANOID
    case GAME_ARKANOID: return ArkanoidGame::isNewRecord();
#endif
#ifdef ENABLE_VSHOOTER
    case GAME_VSHOOTER: return VShooterGame::isNewRecord();
#endif
#ifdef ENABLE_DUNGEON
    case GAME_DUNGEON:  return DungeonGame::isNewRecord();
#endif
#ifdef ENABLE_DOOM
    case GAME_DOOM:     return DoomGame::isNewRecord();
#endif
#ifdef ENABLE_MARIO
    case GAME_MARIO:    return MarioGame::isNewRecord();
#endif
    default: break;
  }
  return false;
}

// ============================================================
//  SPLASH SCREEN
// ============================================================
void drawSplash() {
  if (btnB.held && btnJoySW.held) {
    display.clearDisplay();
    display.setTextColor(SSD1306_WHITE);
    drawCenteredText(8,  "* * * * * * * * *");
    drawCenteredText(20, "BUILT BY");
    drawCenteredText(32, "V  O  I  D", 2);
    drawCenteredText(50, "* * * * * * * * *");
    display.display();
    delay(2200);
    return;
  }

  display.clearDisplay();
  initStars();
  scrollStarsH(1);
  display.setTextColor(SSD1306_WHITE);
  drawCenteredText(6, "RETROBOX", 2);
  drawCenteredText(30, "MULTI-GAME CONSOLE");
  drawCenteredText(40, "v3.8");
  unsigned long elapsed = millis() - splashStart;
  int barW = (int)((elapsed / 2500.0f) * 100);
  if (barW > 100) barW = 100;
  display.drawRect(14, 52, 100, 6, SSD1306_WHITE);
  display.fillRect(15, 53, barW, 4, SSD1306_WHITE);
  display.display();
}

// ============================================================
//  GAME SELECT SCREEN
// ============================================================
void drawGameSelect() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(24, 1);
  display.print("SELECT GAME");
  display.drawLine(0, 9, 127, 9, SSD1306_WHITE);

  int start = max(0, min(selectedGame - 1, GAME_COUNT - 3));
  for (int i = 0; i < 3 && (start + i) < GAME_COUNT; i++) {
    int g = start + i;
    int y = 13 + i * 14;
    bool on = gameEnabled(g);
    if (g == selectedGame) {
      display.fillRect(0, y - 1, 128, 12, SSD1306_WHITE);
      display.setTextColor(SSD1306_BLACK);
    } else {
      display.setTextColor(SSD1306_WHITE);
    }
    display.setCursor(6, y + 1);
    display.print(g == selectedGame ? "> " : (on ? "  " : "- "));
    display.print(GAME_NAMES[g]);
    if (!on) {
      display.setCursor(86, y + 1);
      display.print("(off)");     // compiled out in games_config.h
    } else {
      int best = 0;
      for (int d = 0; d < 3; d++) best = max(best, highScores[g][d]);
      if (best > 0) {
        char buf[16]; snprintf(buf, sizeof(buf), "%d", best);
        display.setCursor(90, y + 1);
        display.print(buf);
      }
    }
  }
  display.setTextColor(SSD1306_WHITE);
  for (int g = 0; g < GAME_COUNT; g++) {
    int dx = 38 + g * 9;
    if (g == selectedGame) display.fillCircle(dx, 61, 2, SSD1306_WHITE);
    else                   display.drawCircle(dx, 61, 2, SSD1306_WHITE);
  }
  display.display();
}

// ============================================================
//  CONTINUE / NEW GAME SELECT                            <SAVE>
// ============================================================
void drawSaveSelect() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  drawCenteredText(1, GAME_NAMES[selectedGame]);
  display.drawLine(0, 10, 127, 10, SSD1306_WHITE);

  const char* opts[2] = { "CONTINUE", "NEW GAME" };
  for (int i = 0; i < 2; i++) {
    int y = 14 + i * 13;
    if (i == saveMenuChoice) {
      display.fillRect(8, y - 1, 112, 11, SSD1306_WHITE);
      display.setTextColor(SSD1306_BLACK);
    } else {
      display.setTextColor(SSD1306_WHITE);
    }
    display.setCursor(14, y + 1);
    display.print(i == saveMenuChoice ? "> " : "  ");
    display.print(opts[i]);
    display.setTextColor(SSD1306_WHITE);
  }

  char lbl[RB_SAVE_LABELLEN];
  SaveHooks h = gameSaveHooks(selectedGame);
  if (!h.tag || !SaveSystem::label(selectedGame, h.tag, lbl, sizeof(lbl)) || !lbl[0])
    strncpy(lbl, "no save", sizeof(lbl) - 1), lbl[sizeof(lbl) - 1] = '\0';
  drawCenteredText(41, lbl);

  drawCenteredText(53, "A=OK   B=Back");
  display.display();
}

// ============================================================
//  SAVE-ON-EXIT PROMPT                                   <SAVE>
// ============================================================
void drawSavePrompt() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.drawRect(0, 0, 128, 64, SSD1306_WHITE);
  drawCenteredText(6,  "SAVE PROGRESS?");
  drawCenteredText(17, GAME_NAMES[selectedGame]);
  display.drawLine(8, 27, 119, 27, SSD1306_WHITE);
  drawCenteredText(31, "A = SAVE AND EXIT");
  drawCenteredText(41, "B = EXIT, NO SAVE");
  drawCenteredText(53, "START = keep playing");
  display.display();
}

// ============================================================
//  DIFFICULTY SELECT
// ============================================================
void drawDifficultySelect() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  drawCenteredText(2, GAME_NAMES[selectedGame]);
  display.drawLine(0, 11, 127, 11, SSD1306_WHITE);
  drawCenteredText(13, "DIFFICULTY");
  for (int i = 0; i < 3; i++) {
    int y = 26 + i * 12;
    if (i == (int)currentDiff) {
      display.fillRect(20, y - 1, 88, 11, SSD1306_WHITE);
      display.setTextColor(SSD1306_BLACK);
      display.setCursor(26, y + 1);
      display.print("> ");
    } else {
      display.setTextColor(SSD1306_WHITE);
      display.setCursor(26, y + 1);
      display.print("  ");
    }
    display.print(DIFF_NAMES[i]);
    display.setTextColor(SSD1306_WHITE);
    if (highScores[selectedGame][i] > 0) {
      char buf[10]; snprintf(buf, sizeof(buf), "%d", highScores[selectedGame][i]);
      display.setCursor(90, y + 1);
      display.print(buf);
    }
  }
  display.setCursor(PLAY_W < 80 ? 2 : 6, 58);
  display.print(PLAY_W < 80 ? "A=OK B=Back" : "A=OK  B=Back");
  display.display();
}

// ============================================================
//  ORIENTATION SELECT
// ============================================================
void drawOriSelect() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  drawCenteredText(2, "ORIENTATION");
  display.drawLine(0, 11, 127, 11, SSD1306_WHITE);
  drawCenteredText(5, "Choose layout:");

  const char* opts[] = {"LANDSCAPE", "PORTRAIT", "LAND.FLIP", "PORT.FLIP"};
  for (int i = 0; i < 4; i++) {
    int y = 14 + i * 11;
    if (i == (int)currentOri) {
      display.fillRect(4, y - 1, 120, 10, SSD1306_WHITE);
      display.setTextColor(SSD1306_BLACK);
      display.setCursor(8, y + 1);
      display.print("> ");
    } else {
      display.setTextColor(SSD1306_WHITE);
      display.setCursor(8, y + 1);
      display.print("  ");
    }
    display.print(opts[i]);
    display.setTextColor(SSD1306_WHITE);
  }
  display.setCursor(6, 58);
  display.print("A=Confirm  B=Back");
  display.display();
}

// ============================================================
//  PAUSE / GAME OVER
// ============================================================
void drawPause() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  drawCenteredText(PLAY_H / 2 - 20, "PAUSED", 2);
  drawCenteredText(PLAY_H / 2 + 4,  "START=resume");
  // <SAVE> games with a save slot get a different hint
  drawCenteredText(PLAY_H / 2 + 14, gameCanSave() ? "B=Save & exit" : "B=Main menu");
  display.display();
}

void drawGameOverScreen(int score, bool newRecord) {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  drawCenteredText(PLAY_H / 2 - 28, "GAME OVER", 2);
  display.drawLine(0, PLAY_H / 2 - 12, PLAY_W - 1, PLAY_H / 2 - 12, SSD1306_WHITE);
  char buf[24];
  snprintf(buf, sizeof(buf), "SCORE: %d", score);
  drawCenteredText(PLAY_H / 2 - 8, buf);
  snprintf(buf, sizeof(buf), "BEST:  %d", highScores[selectedGame][(int)currentDiff]);
  drawCenteredText(PLAY_H / 2 + 2, buf);
  if (newRecord) drawCenteredText(PLAY_H / 2 + 14, "** NEW RECORD! **");
  if (PLAY_W < 80)
    drawCenteredText(PLAY_H - 10, "ST=menu A=retry");
  else
    drawCenteredText(PLAY_H - 10, "START=menu  A=retry");
  display.display();
}

// ============================================================
//  DEV MENU
// ============================================================
void drawDevMenu() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.drawRect(0, 0, 128, 64, SSD1306_WHITE);
  display.setCursor(4, 3);
  display.setTextSize(1);
  display.print("DEV [");
  display.print(devMenuPage + 1);
  display.print("/10]");
  display.drawLine(0, 12, 127, 12, SSD1306_WHITE);

  char l1[32] = "", l2[32] = "", l3[32] = "";
  char bar[12] = "";
  switch (devMenuPage) {
    case 0: snprintf(l1, sizeof(l1), "FREE RAM"); snprintf(l2, sizeof(l2), "%d bytes", (int)ESP.getFreeHeap()); break;
    case 1: snprintf(l1, sizeof(l1), "CPU FREQ"); snprintf(l2, sizeof(l2), "%d MHz", getCpuFrequencyMhz()); break;
    case 2: snprintf(l1, sizeof(l1), "UPTIME"); snprintf(l2, sizeof(l2), "%lu sec", millis() / 1000); break;
    case 3: snprintf(l1, sizeof(l1), "FLASH SIZE"); snprintf(l2, sizeof(l2), "%d KB", (int)(ESP.getFlashChipSize() / 1024));
            snprintf(l3, sizeof(l3), "Sketch:%d KB", (int)(ESP.getSketchSize() / 1024)); break;
    case 4: snprintf(l1, sizeof(l1), "JOY RAW"); snprintf(l2, sizeof(l2), "X:%d  Y:%d", analogRead(JOY_X_PIN), analogRead(JOY_Y_PIN)); break;
    case 5:
            for (int i = 0; i < 10; i++) bar[i] = (i < joystickSensitivity) ? '#' : '-';
            bar[10] = '\0';
            snprintf(l1, sizeof(l1), "JOY SENS %d/10", joystickSensitivity);
            snprintf(l2, sizeof(l2), "[%s]", bar);
            snprintf(l3, sizeof(l3), "UP/DN adjust");
            break;
    case 6: snprintf(l1, sizeof(l1), "HIGH SCORES");
            snprintf(l2, sizeof(l2), "%s E:%d M:%d", GAME_NAMES[selectedGame], highScores[selectedGame][0], highScores[selectedGame][1]);
            snprintf(l3, sizeof(l3), "H:%d", highScores[selectedGame][2]); break;
    // <SAVE> page 7: state of the selected game's save slot
    case 7: snprintf(l1, sizeof(l1), "SAVE SLOT");
            if (!gameCanSave()) {
              snprintf(l2, sizeof(l2), "%s: unsupported", GAME_NAMES[selectedGame]);
            } else if (gameHasSave()) {
              char sl[RB_SAVE_LABELLEN];
              SaveHooks hk = gameSaveHooks(selectedGame);
              SaveSystem::label(selectedGame, hk.tag, sl, sizeof(sl));
              snprintf(l2, sizeof(l2), "%s:", GAME_NAMES[selectedGame]);
              snprintf(l3, sizeof(l3), "%s  A=erase", sl);
            } else {
              snprintf(l2, sizeof(l2), "%s: empty", GAME_NAMES[selectedGame]);
            }
            break;
    case 8: snprintf(l1, sizeof(l1), "FACTORY RESET"); snprintf(l2, sizeof(l2), "A=CONFIRM"); snprintf(l3, sizeof(l3), "Scores + saves!"); break;
    case 9: snprintf(l1, sizeof(l1), "BUILD INFO"); snprintf(l2, sizeof(l2), "RetroBox v3.8");
            snprintf(l3, sizeof(l3), "%d/%d games on", enabledGameCount(), (int)GAME_COUNT); break;
  }

  display.setCursor(4, 16); display.print(l1);
  display.setCursor(4, 28); display.print(l2);
  if (l3[0]) { display.setCursor(4, 40); display.print(l3); }
  display.setCursor(4, 54);
  if (devMenuPage == 5) display.print("L/R page U/D set");
  else display.print("JOY=page A=act B=exit");
  display.display();
}

// ============================================================
//  TUTORIAL SYSTEM
// ============================================================
static int tutorialPage = 0;

struct TutLine { const char* a; const char* b; };
const TutLine TUTORIALS[GAME_COUNT][2][2] = {
  { {{"Dodge oncoming cars","Stay in 3 lanes"},{"L/R=steer  A=nitro","fuel bar=empty=game over"}},
    {{"Fuel pickups on road","3 HP, crashes drain HP"},{"START=pause","Pause+B+A = save & quit"}} },
  { {{"Clear lines to score","stack pieces neatly"},{"Joy L/R = move","A = rotate  D = drop"}},
    {{"More lines = faster","pieces = harder"},{"START=pause","Pause+B+A = save & quit"}} },
  { {{"Eat food to grow","don't hit walls/self"},{"Joy = direction","(opposite = ignore)"}},
    {{"Snake speeds up","as you eat more"},{"3 lives  START=pause","Pause+B+A = save & quit"}} },
  { {{"Smash all bricks","don't let ball fall"},{"Joy L/R = paddle","A = launch ball"}},
    {{"Angle your paddle","to aim the ball"},{"3 lives  START=pause","Pause+B+A = save & quit"}} },
  { {{"Shoot enemy waves","scrolling starfield"},{"Joy L/R = move","A/SW=fire  B=bomb"}},
    {{"Boss every 5 waves","enemies dive at you"},{"3 lives  START=pause","Pause+B+A = save & quit"}} },
  { {{"Explore rooms, find X","exit to reach next floor"},{"Joy=move  A=attack adj","Bump enemy to fight!"}},
    {{"g=goblin o=orc T=Troll","@=you  X=exit  p=potion"},{"^=trap  START=pause","Pause+B+A = save & quit"}} },
  { {{"3D Raycaster FPS!","Compass arrow=EXIT dir"},{"Joy U/D=move  L/R=turn","A=shoot  B=strafe-mode"}},
    {{"SW btn=minimap toggle","Shoot enemies for score"},{"START=pause","Pause+B+A = save & quit"}} },
  // Mario slot unused — Mario uses MARIO_TUT below
  { {{"16 crafted levels","coins save for shop"},{"Joy L/R move  A=jump","B=run/fire SW=reserve"}},
    {{"Flag opens item shop","A=buy  B=next level"},{"START=pause","Pause+B+A = save & quit"}} },
};
// Turns "too few initializers" into a message that says what to fix.
static_assert(sizeof(TUTORIALS) / sizeof(TUTORIALS[0]) == GAME_COUNT,
              "TUTORIALS needs exactly one entry per GameID");

static const int MARIO_TUT_PAGES = 5;
struct MarioTutPage {
  const char* title;
  const char* lines[4];
};
static const MarioTutPage MARIO_TUT[MARIO_TUT_PAGES] = {
  {
    "MARIO - GOAL",
    {
      "Reach the FLAG at the end",
      "of each level to proceed.",
      "16 levels across 4 worlds.",
      "START to pause at any time."
    }
  },
  {
    "MOVEMENT",
    {
      "JOY LEFT/RIGHT  - Walk",
      "Hold B + JOY    - Run faster",
      "JOY DOWN        - Duck",
      "A               - Jump"
    }
  },
  {
    "JUMPING & COMBAT",
    {
      "Hold A longer = higher jump.",
      "Land ON TOP of Goombas/Koopas",
      "to stomp them for points.",
      "Touch from side = lose a life."
    }
  },
  {
    "POWER-UPS & SHOP",
    {
      "Hit ? blocks for power-ups.",
      "Collect 10 coins = +1 Life!",
      "Flag -> ITEM SHOP opens.",
      "SW = use reserve item slot."
    }
  },
  {
    "SAVING & ENEMIES",
    {
      "Pause, press B, then A to",
      "save and quit. Pick CONTINUE",
      "next time to resume.",
      "Koopa: stomp->shell->kick it."
    }
  }
};

static int tutTotalPages() {
  return (selectedGame == GAME_MARIO) ? MARIO_TUT_PAGES : 2;
}

static int drawWrappedText(int x, int y, const char* str, int lineH = 9) {
  int maxW = PLAY_W - x * 2;
  int cpl  = maxW / 6;
  if (cpl < 1) cpl = 1;

  const char* p = str;
  while (*p) {
    int len = strlen(p);
    if (len <= cpl) {
      display.setCursor(x, y);
      display.print(p);
      y += lineH;
      break;
    }
    int cut = cpl;
    for (int i = cpl; i > 0; i--) {
      if (p[i] == ' ') { cut = i; break; }
    }
    char tmp[32];
    int n = min(cut, 31);
    strncpy(tmp, p, n);
    tmp[n] = '\0';
    display.setCursor(x, y);
    display.print(tmp);
    y += lineH;
    p += cut;
    if (*p == ' ') p++;
  }
  return y;
}

void drawTutorial() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);

  bool isPortrait = (PLAY_W <= 64);
  int total = tutTotalPages();

  char header[28];
  if (isPortrait) {
    char abbr[8];
    if (selectedGame == GAME_MARIO) {
      strncpy(abbr, "MARIO", 7); abbr[7] = '\0';
    } else {
      strncpy(abbr, GAME_NAMES[selectedGame], 5);
      abbr[5] = '\0';
    }
    snprintf(header, sizeof(header), "%s %d/%d", abbr, tutorialPage + 1, total);
  } else {
    if (selectedGame == GAME_MARIO) {
      snprintf(header, sizeof(header), "%s (%d/%d)", MARIO_TUT[tutorialPage].title, tutorialPage + 1, total);
    } else {
      snprintf(header, sizeof(header), "%s (%d/%d)", GAME_NAMES[selectedGame], tutorialPage + 1, total);
    }
    header[21] = '\0';
  }
  drawCenteredText(1, header);
  display.drawLine(0, 10, PLAY_W - 1, 10, SSD1306_WHITE);

  int bodyMargin = isPortrait ? 2 : 4;
  int lineH      = isPortrait ? 10 : 9;

  if (selectedGame == GAME_MARIO) {
    const MarioTutPage& pg = MARIO_TUT[tutorialPage];
    int y = 13;
    for (int i = 0; i < 4; i++) {
      if (pg.lines[i] && pg.lines[i][0]) {
        y = drawWrappedText(bodyMargin, y, pg.lines[i], lineH);
        if (y > PLAY_H - 12) break;
      }
    }
  } else {
    const TutLine* pg = TUTORIALS[selectedGame][tutorialPage];
    int y = 13;
    y = drawWrappedText(bodyMargin, y, pg[0].a, lineH);
    y = drawWrappedText(bodyMargin, y, pg[0].b, lineH);
    if (y + 4 < PLAY_H - 14) {
      display.drawLine(bodyMargin + 2, y + 2, PLAY_W - bodyMargin - 2, y + 2, SSD1306_WHITE);
      y += 6;
    } else {
      y += 3;
    }
    y = drawWrappedText(bodyMargin, y, pg[1].a, lineH);
    drawWrappedText(bodyMargin, y, pg[1].b, lineH);
  }

  bool isLast = (tutorialPage >= total - 1);
  const char* hint;
  if (isPortrait) {
    hint = isLast ? "A=go B=bk" : "A=nx B=bk";
  } else {
    hint = isLast ? "A=play  B=back SW=skip" : "A=next  B=back SW=skip";
  }
  drawCenteredText(PLAY_H - 8, hint);

  display.display();
}

// <SAVE> Where the tutorial hands off. Skips the CONTINUE screen entirely
// when the game has no save support or nothing saved.
void gotoAfterTutorial() {
  continueFromSave = false;
  if (gameCanSave() && gameHasSave()) {
    saveMenuChoice = 0;
    appState = STATE_SAVE_SELECT;
  } else {
    appState = STATE_DIFFICULTY_SELECT;
  }
}

// ============================================================
//  SETUP
// ============================================================
void setup() {
  Serial.begin(115200);
  setCpuFrequencyMhz(80);

  WiFi.mode(WIFI_OFF);
  esp_wifi_stop();

  ledcSetup(0, 2000, 8);
  ledcAttachPin(BUZZER_PIN, 0);

  pinMode(BTN_A_PIN,     INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(BTN_A_PIN), btnA_ISR, FALLING);
  pinMode(BTN_B_PIN,     INPUT_PULLUP);
  pinMode(BTN_START_PIN, INPUT_PULLUP);
  pinMode(JOY_SW_PIN,    INPUT_PULLUP);
  pinMode(ONBOARD_LED,   OUTPUT);
  digitalWrite(ONBOARD_LED, LOW);

  recoverI2CBus();
  bool oledOk = false;
  for (int attempt = 0; attempt < 5 && !oledOk; attempt++) {
    if (display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) oledOk = true;
    else { recoverI2CBus(); delay(100); }
  }
  if (!oledOk) {
    while (true) {
      digitalWrite(ONBOARD_LED, HIGH); delay(200);
      digitalWrite(ONBOARD_LED, LOW);  delay(200);
    }
  }
  display.setTextColor(SSD1306_WHITE);
  display.setRotation(0);
  display.clearDisplay();
  display.display();

  loadAllScores();
  loadSettings();
  SaveSystem::begin();              // <SAVE> create the namespace on a virgin chip
  selectedGame = firstEnabledGame();

  splashStart = millis();
  appState = STATE_SPLASH;
  sfxPower();
}

// ============================================================
//  MAIN LOOP
// ============================================================
void loop() {
  unsigned long now = millis();
  if (now - lastFrameTime < FRAME_MS) return;
  lastFrameTime = now;

  readButtons();
  checkDevHold();

  switch (appState) {

    case STATE_SPLASH:
      drawSplash();
      if (millis() - splashStart > 2800 || btnStart.pressed) {
        resetOrientation();
        appState = STATE_GAME_SELECT;
      }
      break;

    case STATE_GAME_SELECT: {
      static unsigned long lastNav = 0;
      if (millis() - lastNav > 160) {
        // Skip games that were compiled out in games_config.h.
        if (joyMenuUp())   { int g = nextEnabledGame(selectedGame, -1); if (g != selectedGame) { selectedGame = g; sfxMenu(); lastNav = millis(); } }
        if (joyMenuDown()) { int g = nextEnabledGame(selectedGame, +1); if (g != selectedGame) { selectedGame = g; sfxMenu(); lastNav = millis(); } }
      }
      drawGameSelect();
      bool go = btnA.pressed || (btnStart.pressed && !devHolding);
      if (go && gameEnabled(selectedGame)) { sfxConfirm(); tutorialPage = 0; appState = STATE_TUTORIAL; }
      else if (go) sfxBack();
      break;
    }

    case STATE_TUTORIAL: {
      drawTutorial();
      int totPages = tutTotalPages();
      if (btnA.pressed) {
        if (tutorialPage < totPages - 1) { tutorialPage++; sfxMenu(); }
        else { sfxConfirm(); gotoAfterTutorial(); }        // <SAVE>
      }
      if (btnB.pressed) {
        if (tutorialPage > 0) { tutorialPage--; sfxMenu(); }
        else { sfxBack(); appState = STATE_GAME_SELECT; }
      }
      if (btnJoySW.pressed || btnStart.pressed) { sfxConfirm(); tutorialPage = 0; gotoAfterTutorial(); }  // <SAVE>
      break;
    }

    // ── CONTINUE / NEW GAME ──────────────────────────────  <SAVE>
    case STATE_SAVE_SELECT: {
      static unsigned long lastNavS = 0;
      if (millis() - lastNavS > 160) {
        if (joyMenuUp()   && saveMenuChoice > 0) { saveMenuChoice--; sfxMenu(); lastNavS = millis(); }
        if (joyMenuDown() && saveMenuChoice < 1) { saveMenuChoice++; sfxMenu(); lastNavS = millis(); }
      }
      drawSaveSelect();
      if (btnA.pressed) {
        continueFromSave = (saveMenuChoice == 0);
        if (continueFromSave) {
          // Pre-select the difficulty / orientation the save was made on.
          SaveHooks h = gameSaveHooks(selectedGame);
          uint8_t d, o;
          if (h.tag && SaveSystem::peek(selectedGame, h.tag, &d, &o)) {
            if (d < 3) currentDiff = (Difficulty)d;
            if (o < 4) currentOri  = (Orientation)o;
          }
        }
        // NEW GAME does NOT erase the slot — it stays until the next
        // save overwrites it.
        sfxConfirm();
        appState = STATE_DIFFICULTY_SELECT;
      } else if (btnB.pressed) {
        sfxBack();
        continueFromSave = false;
        appState = STATE_GAME_SELECT;
      }
      break;
    }

    case STATE_DIFFICULTY_SELECT: {
      static unsigned long lastNav2 = 0;
      if (millis() - lastNav2 > 160) {
        if (joyMenuUp()   && (int)currentDiff > 0) { currentDiff = (Difficulty)((int)currentDiff - 1); sfxMenu(); lastNav2 = millis(); }
        if (joyMenuDown() && (int)currentDiff < 2) { currentDiff = (Difficulty)((int)currentDiff + 1); sfxMenu(); lastNav2 = millis(); }
      }
      drawDifficultySelect();
      if (btnA.pressed) { sfxConfirm(); appState = STATE_ORI_SELECT; }
      if (btnB.pressed) { sfxBack();    appState = STATE_GAME_SELECT; }
      break;
    }

    case STATE_ORI_SELECT: {
      static unsigned long lastNavO = 0;
      if (millis() - lastNavO > 160) {
        if (joyMenuUp()   && (int)currentOri > 0) { currentOri = (Orientation)((int)currentOri - 1); sfxMenu(); lastNavO = millis(); }
        if (joyMenuDown() && (int)currentOri < 3) { currentOri = (Orientation)((int)currentOri + 1); sfxMenu(); lastNavO = millis(); }
      }
      drawOriSelect();
      if (btnA.pressed) { sfxConfirm(); applyOrientation(); gameInit(continueFromSave); appState = STATE_PLAYING; }  // <SAVE>
      if (btnB.pressed) { sfxBack(); appState = STATE_DIFFICULTY_SELECT; }
      break;
    }

    case STATE_PLAYING:
      gameUpdate();
      gameDraw();
      if (gameIsOver()) {
        saveScore(selectedGame, (int)currentDiff, gameGetScore());
        ledcWriteTone(0, 0);
        gameOverEnteredAt = millis();
        appState = STATE_GAME_OVER;
        break;
      }
      if (btnStart.pressed) { appState = STATE_PAUSED; sfxMenu(); }
      break;

    case STATE_PAUSED:
      drawPause();
      if (btnStart.pressed) { appState = STATE_PLAYING; sfxConfirm(); }
      else if (btnB.pressed) {                                   // <SAVE>
        if (gameCanSave()) { sfxMenu(); appState = STATE_SAVE_PROMPT; }
        else {
          saveScore(selectedGame, (int)currentDiff, gameGetScore());
          sfxBack(); resetOrientation(); appState = STATE_GAME_SELECT;
        }
      }
      break;

    // ── SAVE PROGRESS?  A = yes, B = no, START = back ────  <SAVE>
    case STATE_SAVE_PROMPT:
      drawSavePrompt();
      if (btnA.pressed) {
        bool ok = gameSaveNow();
        // The high score is a separate thing from the save slot and is
        // always worth keeping, so commit it on the way out either way.
        saveScore(selectedGame, (int)currentDiff, gameGetScore());
        if (ok) sfxLevelUp(); else sfxHit();
        flashMessage(ok ? "PROGRESS" : "COULD NOT", ok ? "SAVED" : "SAVE", 900);
        continueFromSave = false;
        resetOrientation();
        appState = STATE_GAME_SELECT;
      } else if (btnB.pressed) {
        saveScore(selectedGame, (int)currentDiff, gameGetScore());
        sfxBack();
        continueFromSave = false;
        resetOrientation();
        appState = STATE_GAME_SELECT;
      } else if (btnStart.pressed) {
        sfxMenu();
        appState = STATE_PAUSED;
      }
      break;

    case STATE_GAME_OVER:
      drawGameOverScreen(gameGetScore(), gameIsNewRecord());
      if (millis() - gameOverEnteredAt > 1500) {
        if (btnStart.pressed) { sfxBack(); resetOrientation(); appState = STATE_GAME_SELECT; }
        // Retry re-uses whatever the player chose at the start of the run:
        // come in on CONTINUE and you restart from the save point.
        if (btnA.pressed) { sfxConfirm(); applyOrientation(); gameInit(continueFromSave); appState = STATE_PLAYING; }  // <SAVE>
      }
      break;

    case STATE_DEV_MENU: {
      static unsigned long lastDevNav = 0;
      drawDevMenu();
      if (millis() - lastDevNav > 220) {
        if (joyMenuRight() && devMenuPage < 9) { devMenuPage++; sfxMenu(); lastDevNav = millis(); }
        if (joyMenuLeft()  && devMenuPage > 0) { devMenuPage--; sfxMenu(); lastDevNav = millis(); }
        if (devMenuPage == 5 && joyMenuUp() && joystickSensitivity < 10) {
          joystickSensitivity++;
          saveJoystickSensitivity();
          sfxMenu();
          lastDevNav = millis();
        }
        if (devMenuPage == 5 && joyMenuDown() && joystickSensitivity > 1) {
          joystickSensitivity--;
          saveJoystickSensitivity();
          sfxMenu();
          lastDevNav = millis();
        }
      }
      if (btnA.pressed) {
        if (devMenuPage == 7) {                         // <SAVE> erase this slot
          if (gameHasSave()) { SaveSystem::clear(selectedGame); sfxBack(); }
          else sfxHit();
        }
        else if (devMenuPage == 8) { factoryReset(); sfxGameOver(); }
        else sfxConfirm();
      }
      if (btnB.pressed || btnStart.pressed) { sfxBack(); appState = STATE_GAME_SELECT; }
      break;
    }
  }
  clearButtons();
}

// ============================================================
//  END OF FILE — RETROBOX v3.8  | built by VOID
// ============================================================
