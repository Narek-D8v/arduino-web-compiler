#include <Arduino.h>
#include <SPI.h>
#include <TFT_eSPI.h>
#include <XPT2046_Touchscreen.h>
#include <WiFi.h>

// GLASER OS v1 — for the classic ESP32-2432S028 (CYD) board.
// LCD: ILI9341 on GPIO 12/13/14, CS=15, DC=2, backlight=21.
// Touch: XPT2046 on its separate SPI pins 25/39/32, CS=33, IRQ=36.

static constexpr int TOUCH_SCK = 25;
static constexpr int TOUCH_MISO = 39;
static constexpr int TOUCH_MOSI = 32;
static constexpr int TOUCH_CS = 33;
static constexpr int TOUCH_IRQ = 36;

// Approximate initial calibration. If taps land incorrectly, use Settings > Touch
// in a future calibration build or adjust these bounds for your individual panel.
static constexpr int RAW_X_MIN = 250;
static constexpr int RAW_X_MAX = 3850;
static constexpr int RAW_Y_MIN = 250;
static constexpr int RAW_Y_MAX = 3850;

TFT_eSPI tft;
SPIClass touchSPI(HSPI);
XPT2046_Touchscreen touch(TOUCH_CS, TOUCH_IRQ, touchSPI);

enum Screen { HOME, SYSTEM_INFO, NETWORK_INFO, ABOUT };
Screen currentScreen = HOME;
uint32_t lastTapMs = 0;

uint16_t C_BG = 0x0841;
uint16_t C_PANEL = 0x10A2;
uint16_t C_CYAN = 0x07FF;
uint16_t C_GREEN = 0x07E0;
uint16_t C_WHITE = TFT_WHITE;
uint16_t C_MUTED = 0xAD55;
uint16_t C_ORANGE = 0xFD20;

int16_t rawToX(int16_t raw) {
  long v = map(raw, RAW_X_MIN, RAW_X_MAX, 0, tft.width());
  return constrain((int)v, 0, tft.width() - 1);
}
int16_t rawToY(int16_t raw) {
  long v = map(raw, RAW_Y_MIN, RAW_Y_MAX, 0, tft.height());
  return constrain((int)v, 0, tft.height() - 1);
}

void header(const char *title) {
  tft.fillScreen(C_BG);
  tft.fillRect(0, 0, tft.width(), 44, C_PANEL);
  tft.setTextColor(C_CYAN, C_PANEL);
  tft.setTextFont(2);
  tft.setCursor(12, 8);
  tft.print("GLASER OS");
  tft.setTextColor(C_WHITE, C_PANEL);
  tft.setCursor(12, 27);
  tft.print(title);
  tft.drawFastHLine(0, 44, tft.width(), C_CYAN);
}

void drawButton(int x, int y, int w, int h, const char *label, uint16_t color) {
  tft.fillRoundRect(x, y, w, h, 8, C_PANEL);
  tft.drawRoundRect(x, y, w, h, 8, color);
  tft.setTextFont(2);
  tft.setTextColor(color, C_PANEL);
  int16_t tw = tft.textWidth(label);
  tft.setCursor(x + (w - tw) / 2, y + (h - 16) / 2);
  tft.print(label);
}

void drawHome() {
  header("PERSONAL EMBEDDED SYSTEM");
  tft.setTextFont(4);
  tft.setTextColor(C_WHITE, C_BG);
  tft.setCursor(16, 62);
  tft.print("WELCOME");
  tft.setTextFont(2);
  tft.setTextColor(C_MUTED, C_BG);
  tft.setCursor(16, 94);
  tft.print("Your device. Your interface.");
  drawButton(12, 125, 100, 58, "SYSTEM", C_CYAN);
  drawButton(128, 125, 100, 58, "NETWORK", C_GREEN);
  drawButton(12, 197, 100, 58, "ABOUT", C_ORANGE);
  drawButton(128, 197, 100, 58, "REFRESH", C_CYAN);
  tft.setTextFont(1);
  tft.setTextColor(C_MUTED, C_BG);
  tft.setCursor(12, 290);
  tft.printf("Uptime: %lu sec", millis() / 1000UL);
  tft.setCursor(12, 304);
  tft.print("Tap a tile to open it");
}

void drawSystemInfo() {
  header("SYSTEM INFORMATION");
  tft.setTextFont(2);
  tft.setTextColor(C_WHITE, C_BG);
  tft.setCursor(12, 62); tft.printf("Chip: %s", ESP.getChipModel());
  tft.setCursor(12, 88); tft.printf("Cores: %d", ESP.getChipCores());
  tft.setCursor(12, 114); tft.printf("CPU: %u MHz", ESP.getCpuFreqMHz());
  tft.setCursor(12, 140); tft.printf("Heap free: %u KB", ESP.getFreeHeap() / 1024);
  tft.setCursor(12, 166); tft.printf("Flash: %u MB", ESP.getFlashChipSize() / (1024 * 1024));
  tft.setCursor(12, 192); tft.printf("Uptime: %lu sec", millis() / 1000UL);
  drawButton(12, 250, 100, 48, "HOME", C_CYAN);
  drawButton(128, 250, 100, 48, "REFRESH", C_GREEN);
}

void drawNetworkInfo() {
  header("NETWORK STATUS");
  tft.setTextFont(2);
  tft.setTextColor(C_WHITE, C_BG);
  tft.setCursor(12, 68); tft.print("Wi-Fi mode:");
  tft.setTextColor(C_CYAN, C_BG);
  tft.setCursor(12, 92); tft.print("Not connected by default");
  tft.setTextColor(C_MUTED, C_BG);
  tft.setCursor(12, 130); tft.print("GLASER OS does not join a network");
  tft.setCursor(12, 152); tft.print("until you add Wi-Fi settings.");
  drawButton(12, 250, 100, 48, "HOME", C_CYAN);
  drawButton(128, 250, 100, 48, "REFRESH", C_GREEN);
}

void drawAbout() {
  header("ABOUT GLASER OS");
  tft.setTextFont(4);
  tft.setTextColor(C_CYAN, C_BG);
  tft.setCursor(12, 70); tft.print("GLASER OS");
  tft.setTextFont(2);
  tft.setTextColor(C_WHITE, C_BG);
  tft.setCursor(12, 112); tft.print("Version 1.0.0");
  tft.setTextColor(C_MUTED, C_BG);
  tft.setCursor(12, 145); tft.print("Custom ESP32 touchscreen UI");
  tft.setCursor(12, 168); tft.print("Board: ESP32-2432S028");
  tft.setCursor(12, 191); tft.print("Display: ILI9341 240x320");
  tft.setCursor(12, 214); tft.print("Touch: XPT2046");
  drawButton(12, 260, 100, 44, "HOME", C_CYAN);
}

void render() {
  switch (currentScreen) {
    case HOME: drawHome(); break;
    case SYSTEM_INFO: drawSystemInfo(); break;
    case NETWORK_INFO: drawNetworkInfo(); break;
    case ABOUT: drawAbout(); break;
  }
}

bool readTap(int16_t &x, int16_t &y) {
  if (!touch.touched()) return false;
  TS_Point p = touch.getPoint();
  // Most 2432S028 panels are mounted in landscape/portrait variants.
  // These mappings are a safe starting point, but may need per-panel calibration.
  x = rawToX(p.x);
  y = rawToY(p.y);
  return true;
}

void handleTap(int16_t x, int16_t y) {
  if (currentScreen == HOME) {
    if (y >= 125 && y <= 183 && x < 120) currentScreen = SYSTEM_INFO;
    else if (y >= 125 && y <= 183 && x >= 120) currentScreen = NETWORK_INFO;
    else if (y >= 197 && y <= 255 && x < 120) currentScreen = ABOUT;
    else if (y >= 197 && y <= 255 && x >= 120) { /* redraw home */ }
    else return;
  } else {
    if (y >= 245 && y <= 310 && x < 120) currentScreen = HOME;
    else if (y >= 245 && y <= 310 && x >= 120) { /* refresh current page */ }
    else return;
  }
  render();
}

void setup() {
  Serial.begin(115200);
  pinMode(21, OUTPUT);
  digitalWrite(21, HIGH);
  tft.init();
  tft.setRotation(0); // Portrait 240x320; change to 1 for landscape if desired.
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextFont(2);
  tft.setCursor(20, 130);
  tft.print("Starting GLASER OS...");
  touchSPI.begin(TOUCH_SCK, TOUCH_MISO, TOUCH_MOSI, TOUCH_CS);
  touch.begin();
  touch.setRotation(0);
  delay(500);
  render();
  Serial.println("GLASER OS started");
}

void loop() {
  int16_t x, y;
  if (millis() - lastTapMs > 220 && readTap(x, y)) {
    lastTapMs = millis();
    Serial.printf("Touch x=%d y=%d\n", x, y);
    handleTap(x, y);
    while (touch.touched()) delay(10);
  }
  delay(10);
}
