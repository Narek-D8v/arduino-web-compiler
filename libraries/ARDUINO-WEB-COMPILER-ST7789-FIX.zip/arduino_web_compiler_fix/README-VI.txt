FIX LỖI THIẾU Adafruit_ST7789.h TRONG NAREK-D8V/arduino-web-compiler

Nguyên nhân từ log:
Arduino CLI tìm thấy ZIP thư viện trong thư mục libraries/ nhưng từ chối cài vì:
--git-url and --zip-path are disabled by default

Sửa đúng ở workflow của REPOSITORY TRÌNH BIÊN DỊCH (không phải repo game):
Mở .github/workflows/compile.yml, tìm bước chạy `arduino-cli config init`.
Ngay sau lệnh đó, thêm:

  arduino-cli config set library.enable_unsafe_install true

Ví dụ:

- name: Configure Arduino CLI
  run: |
    arduino-cli config init
    arduino-cli config set library.enable_unsafe_install true

Giữ nguyên các lệnh cài thư viện ZIP hiện có ở bước sau. Sau khi bật tùy chọn này, lệnh cài ZIP trong thư mục libraries/ mới được phép chạy và thư viện Adafruit ST7735/ST7789 có thể được cài đúng cách.

LƯU Ý QUAN TRỌNG:
- Đây là thay đổi workflow của Narek-D8v/arduino-web-compiler. Chỉ sửa ZIP bộ game không thể thay đổi workflow chạy trên máy chủ.
- Nếu mày chỉ dùng website công khai và không có quyền sửa workflow máy chủ, cần dùng bản fork/deploy riêng đã áp dụng thay đổi này hoặc nhờ chủ repo sửa.
- Không bật tùy chọn này nếu workflow cài ZIP từ nguồn không đáng tin cậy; nó cho phép cài thư viện ZIP/Git chưa qua Library Manager.

Lỗi git author identity trong log là lỗi khác ở bước dọn dẹp/commit sau build; xử lý riêng nếu vẫn xuất hiện sau khi sửa lỗi cài thư viện.
