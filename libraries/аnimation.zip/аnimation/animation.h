#ifndef ANIMATION_H
#define ANIMATION_H

#include <Arduino.h>

// Объявляем массив как внешний (extern)
extern const uint8_t oled_frames[10][1024]; 

#endif