// ============================================================
//  save_system.h  —  RETROBOX universal save-slot system
//  Author:  VOID (https://github.com/VOID016)
//  License: MIT
// ------------------------------------------------------------
//  ONE SAVE SLOT PER GAME. Saving again overwrites that game's
//  slot and touches nothing else. High scores live in a separate
//  NVS namespace ("rb24") and are unaffected.
//
//  This file is the STORAGE ENGINE only. It knows how to put a
//  lump of bytes in flash and get it back intact. It knows
//  nothing about any game.
//
//  Each game supplies its own three functions — see SAVE_SYSTEM.md
//  and the "SAVE SLOT" section near the bottom of any game_*.h:
//
//      size_t captureState(void* out, size_t max);
//      bool   restoreState(const void* in, size_t len);
//      void   saveLabel(char* out, size_t n);
//
//  Games that don't implement them simply have no save. Nothing
//  breaks: the CONTINUE screen is skipped and pause->B exits
//  straight to the menu, exactly as it did before v3.8.
//
//  SAFETY PROPERTIES (all tested in sim/ — see SAVE_SYSTEM.md)
//   * CRC32 over the payload. A corrupt or half-written slot
//     reads as "no save", never as garbage state.
//   * Game-name tag inside the slot. Reordering the GameID enum
//     can never feed Tetris's bytes to Snake.
//   * Blob size + version recorded in every payload, so changing
//     a game's SaveBlob layout invalidates old saves instead of
//     silently misreading them.
//   * Screen geometry recorded, so a landscape save can't be
//     restored into a portrait board.
//   * Data written before metadata, so power loss mid-write
//     fails the CRC check rather than producing a mismatched pair.
// ============================================================
#pragma once
#include <Preferences.h>
#include <string.h>
#include <stdio.h>

// Provided by the main sketch. Declared extern because the game
// headers (and this one) are included before they are defined.
extern int PLAY_W, PLAY_H;

// ── Tunables ────────────────────────────────────────────────
#define RB_SAVE_NS       "rbsave"   // NVS namespace, separate from "rb24" scores
#define RB_SAVE_FORMAT   1          // bump to invalidate EVERY save on the device
#define RB_SAVE_MAXBLOB  320        // largest per-game payload, bytes.
                                    // Tetris is the biggest at 224 (a 10x20
                                    // board is 200 of those). Raise this if
                                    // your game needs more; it costs one
                                    // stack buffer of this size in the sketch.
#define RB_SAVE_LABELLEN 20         // chars shown on the CONTINUE screen
#define RB_SAVE_TAGLEN    8         // game-name tag stored alongside the slot

// ════════════════════════════════════════════════════════════
//  SaveHead — the first field of every game's SaveBlob
// ════════════════════════════════════════════════════════════
//  Put one of these at the top of your struct and call
//  saveHeadFill() / saveHeadOk() around it. It costs 8 bytes and
//  buys you three guarantees for free:
//
//    blobVer   your own layout version. Bump it when you add or
//              remove a field, and old saves are rejected rather
//              than misread.
//    blobSize  sizeof(YourBlob). Catches the case where you
//              changed the layout and FORGOT to bump blobVer.
//    pw / ph   PLAY_W / PLAY_H at save time. Stops a landscape
//              save being poured into a portrait playfield.
// ════════════════════════════════════════════════════════════
struct SaveHead {
  uint8_t  blobVer;
  uint8_t  pw;
  uint8_t  ph;
  uint8_t  spare;
  uint32_t blobSize;
};

static inline void saveHeadFill(SaveHead& h, uint8_t ver, size_t blobSize) {
  h.blobVer  = ver;
  h.pw       = (uint8_t)PLAY_W;
  h.ph       = (uint8_t)PLAY_H;
  h.spare    = 0;
  h.blobSize = (uint32_t)blobSize;
}

static inline bool saveHeadOk(const SaveHead& h, uint8_t ver, size_t blobSize) {
  return h.blobVer  == ver
      && h.blobSize == (uint32_t)blobSize
      && h.pw       == (uint8_t)PLAY_W
      && h.ph       == (uint8_t)PLAY_H;
}

namespace SaveSystem {

static constexpr uint16_t MAGIC = 0x5242;   // 'R','B'

// Slot header, stored under its own NVS key so the payload and its
// integrity data can be validated independently.
struct Meta {
  uint16_t magic;
  uint8_t  format;
  uint8_t  diff;                     // Difficulty the run was played on
  uint8_t  ori;                      // Orientation the run was played on
  uint8_t  spare;
  uint16_t len;                      // payload length in bytes
  uint32_t crc;                      // CRC32 of the payload
  char     tag  [RB_SAVE_TAGLEN];    // game name — survives enum reordering
  char     label[RB_SAVE_LABELLEN];  // human-readable, shown in the menu
};

static Preferences nvs;

// ── CRC32 (bitwise — no 1 KB lookup table eating RAM) ───────
static uint32_t crc32(const void* data, size_t len) {
  const uint8_t* p = (const uint8_t*)data;
  uint32_t crc = 0xFFFFFFFFUL;
  while (len--) {
    crc ^= *p++;
    for (uint8_t k = 0; k < 8; k++)
      crc = (crc >> 1) ^ (0xEDB88320UL & (0u - (crc & 1u)));
  }
  return ~crc;
}

static void keyMeta(char* k, int g) { snprintf(k, 10, "m%d", g); }
static void keyData(char* k, int g) { snprintf(k, 10, "d%d", g); }

static bool tagMatches(const Meta& m, const char* tag) {
  if (!tag) return false;
  char want[RB_SAVE_TAGLEN];
  memset(want, 0, sizeof(want));
  strncpy(want, tag, RB_SAVE_TAGLEN - 1);
  return memcmp(m.tag, want, RB_SAVE_TAGLEN) == 0;
}

// Call once from setup(). Creates the namespace so later read-only
// opens don't fail on a factory-fresh chip.
inline void begin() {
  if (nvs.begin(RB_SAVE_NS, false)) nvs.end();
}

static bool readMeta(int g, const char* tag, Meta& m) {
  if (g < 0) return false;
  char k[10]; keyMeta(k, g);
  if (!nvs.begin(RB_SAVE_NS, true)) return false;
  size_t got = nvs.getBytes(k, &m, sizeof(Meta));
  nvs.end();
  return got == sizeof(Meta)
      && m.magic  == MAGIC
      && m.format == RB_SAVE_FORMAT
      && m.len > 0 && m.len <= RB_SAVE_MAXBLOB
      && tagMatches(m, tag);
}

// Is there a usable save for this game?
inline bool exists(int g, const char* tag) { Meta m; return readMeta(g, tag, m); }

// Difficulty / orientation the save was made on, without loading the payload.
inline bool peek(int g, const char* tag, uint8_t* diff, uint8_t* ori) {
  Meta m;
  if (!readMeta(g, tag, m)) return false;
  if (diff) *diff = m.diff;
  if (ori)  *ori  = m.ori;
  return true;
}

// One-line description for the CONTINUE screen.
inline bool label(int g, const char* tag, char* out, size_t n) {
  if (!out || n == 0) return false;
  Meta m;
  if (!readMeta(g, tag, m)) { out[0] = '\0'; return false; }
  size_t copy = (n - 1 < RB_SAVE_LABELLEN) ? n - 1 : RB_SAVE_LABELLEN;
  memcpy(out, m.label, copy);
  out[copy] = '\0';
  out[n - 1] = '\0';
  return true;
}

// Write (or overwrite) this game's slot.
inline bool save(int g, const char* tag, uint8_t diff, uint8_t ori,
                 const void* blob, size_t len, const char* lbl) {
  if (g < 0 || !tag || !blob) return false;
  if (len == 0 || len > RB_SAVE_MAXBLOB) return false;

  Meta m;
  memset(&m, 0, sizeof(m));
  m.magic  = MAGIC;
  m.format = RB_SAVE_FORMAT;
  m.diff   = diff;
  m.ori    = ori;
  m.len    = (uint16_t)len;
  m.crc    = crc32(blob, len);
  strncpy(m.tag, tag, RB_SAVE_TAGLEN - 1);
  if (lbl) strncpy(m.label, lbl, RB_SAVE_LABELLEN - 1);

  char kd[10], km[10];
  keyData(kd, g); keyMeta(km, g);
  if (!nvs.begin(RB_SAVE_NS, false)) return false;
  // Payload first, metadata second. If power dies in between, the stale
  // metadata won't match the new payload's CRC, so load() reports "no
  // save" instead of handing a game a mismatched blob.
  size_t a = nvs.putBytes(kd, blob, len);
  size_t b = (a == len) ? nvs.putBytes(km, &m, sizeof(Meta)) : 0;
  nvs.end();
  return (a == len) && (b == sizeof(Meta));
}

// Read this game's slot into `blob`. Returns bytes read, or 0 if the slot
// is missing, corrupt, from another game, or bigger than your buffer.
inline size_t load(int g, const char* tag, uint8_t* diff, uint8_t* ori,
                   void* blob, size_t maxLen) {
  if (!blob) return 0;
  Meta m;
  if (!readMeta(g, tag, m)) return 0;
  if (m.len > maxLen) return 0;

  char kd[10]; keyData(kd, g);
  if (!nvs.begin(RB_SAVE_NS, true)) return 0;
  size_t got = nvs.getBytes(kd, blob, m.len);
  nvs.end();

  if (got != m.len)                return 0;
  if (crc32(blob, m.len) != m.crc) return 0;
  if (diff) *diff = m.diff;
  if (ori)  *ori  = m.ori;
  return m.len;
}

// Delete one game's slot.
inline void clear(int g) {
  if (g < 0) return;
  char kd[10], km[10];
  keyData(kd, g); keyMeta(km, g);
  if (!nvs.begin(RB_SAVE_NS, false)) return;
  nvs.remove(km);   // metadata first: the slot reads as empty immediately
  nvs.remove(kd);
  nvs.end();
}

// Delete every slot (hooked into the dev-menu factory reset).
inline void wipeAll() {
  if (!nvs.begin(RB_SAVE_NS, false)) return;
  nvs.clear();
  nvs.end();
}

} // namespace SaveSystem
