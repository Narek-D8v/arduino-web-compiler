// ============================================================
//  game_arkanoid.h  —  RETROBOX built-in game
//  Arkanoid — ball, paddle, brick breaker
// ============================================================
#pragma once
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Preferences.h>
#include <math.h>
#include "retrobox_types.h"
#include "save_system.h"

extern Adafruit_SSD1306 display;
extern Preferences       prefs;
extern int  PLAY_W, PLAY_H;
extern int  highScores[][3];
extern int  selectedGame;
extern Difficulty currentDiff;
extern bool joyLeft(), joyRight(), joyUp(), joyDown();
extern int  joyMoveStep();
extern Button btnA, btnB, btnStart, btnJoySW;
extern void sfxBeep(), sfxConfirm(), sfxBack(), sfxShoot();
extern void sfxExplode(), sfxGameOver(), sfxLevelUp(), sfxMenu(), sfxHit();
extern void saveScore(int game, int diff, int score);
extern void drawCenteredText(int y, const char* str, int size);
extern void scrollStarsV(int* sx, int* sy, int n, int speed);
extern void drawShip(int x, int y);

namespace ArkanoidGame {
  static const int MAX_ROWS = 6;
  static const int MAX_COLS = 12;

  static int PADDLE_Y, PADDLE_W;
  static const int PADDLE_H  = 3;
  static const int BALL_R    = 2;
  static int BRICK_W, BRICK_H, BRICK_COLS, BRICK_ROWS, BRICK_XOFF, BRICK_YOFF;

  static int   paddleX;
  static float ballX, ballY, ballVx, ballVy;
  static bool  bricks[MAX_ROWS][MAX_COLS];
  static int   score, lives, level;
  static bool  gameOver, newRecord, ballLaunched;

  int bricksRemaining() {
    int n = 0;
    for (int r = 0; r < BRICK_ROWS; r++)
      for (int c = 0; c < BRICK_COLS; c++)
        if (bricks[r][c]) n++;
    return n;
  }

  void resetBall() {
    ballX = paddleX + PADDLE_W / 2;
    ballY = PADDLE_Y - BALL_R - 2;
    float speed = 1.8f + level * 0.15f;
    if (speed > 3.5f) speed = 3.5f;
    ballVx = (random(0, 2) ? 1 : -1) * speed * 0.7f;
    ballVy = -speed;
    ballLaunched = false;
  }

  void initBricks() {
    for (int r = 0; r < MAX_ROWS; r++)
      for (int c = 0; c < MAX_COLS; c++)
        bricks[r][c] = (r < BRICK_ROWS && c < BRICK_COLS);
  }

  void init() {
    PADDLE_Y = PLAY_H - 6;
    PADDLE_W = max(14, PLAY_W / 7);
    BRICK_W  = max(9,  PLAY_W / 11);
    BRICK_H  = 5;
    BRICK_COLS = (PLAY_W - 8) / BRICK_W;
    if (BRICK_COLS > MAX_COLS) BRICK_COLS = MAX_COLS;
    if (BRICK_COLS < 1)        BRICK_COLS = 1;
    BRICK_ROWS = (currentDiff == DIFF_EASY) ? 3 : (currentDiff == DIFF_HARD) ? 5 : 4;
    if (BRICK_ROWS > MAX_ROWS) BRICK_ROWS = MAX_ROWS;
    BRICK_XOFF = (PLAY_W - BRICK_COLS * BRICK_W) / 2;
    BRICK_YOFF = 10;

    paddleX = (PLAY_W - PADDLE_W) / 2;
    score = 0; lives = 3; level = 1; gameOver = false; newRecord = false;
    initBricks();
    resetBall();
  }

  void update() {
    if (gameOver) return;
    if (joyLeft()  && paddleX > 2)               paddleX -= joyMoveStep() + 1;
    if (joyRight() && paddleX < PLAY_W - PADDLE_W - 2) paddleX += joyMoveStep() + 1;

    if (!ballLaunched && btnA.pressed) { ballLaunched = true; sfxBeep(); }
    if (!ballLaunched) { ballX = paddleX + PADDLE_W / 2; return; }

    ballX += ballVx;
    ballY += ballVy;

    if (ballX <= BALL_R)            { ballX = BALL_R;            ballVx = fabs(ballVx); }
    if (ballX >= PLAY_W - BALL_R)   { ballX = PLAY_W - BALL_R;   ballVx = -fabs(ballVx); }
    if (ballY <= BALL_R + 9)        { ballY = BALL_R + 9;         ballVy = fabs(ballVy); }

    if (ballY > PLAY_H + 4) {
      sfxExplode(); lives--;
      if (lives <= 0) { gameOver = true; sfxGameOver(); return; }
      resetBall(); return;
    }

    if (ballY + BALL_R >= PADDLE_Y && ballY - BALL_R <= PADDLE_Y + PADDLE_H &&
        ballX >= paddleX && ballX <= paddleX + PADDLE_W) {
      ballVy = -fabs(ballVy);
      float offset = (ballX - (paddleX + PADDLE_W / 2.0f)) / (PADDLE_W / 2.0f);
      ballVx = offset * 2.5f;
      if (fabs(ballVx) < 0.2f) ballVx = 0.3f;
      sfxBeep();
    }

    for (int r = 0; r < BRICK_ROWS; r++) {
      for (int c = 0; c < BRICK_COLS; c++) {
        if (!bricks[r][c]) continue;
        int bx = BRICK_XOFF + c * BRICK_W;
        int by = BRICK_YOFF + r * BRICK_H;
        if (ballX + BALL_R > bx && ballX - BALL_R < bx + BRICK_W &&
            ballY + BALL_R > by && ballY - BALL_R < by + BRICK_H) {
          bricks[r][c] = false;
          sfxBeep();
          float oL = (ballX + BALL_R) - bx, oR = (bx + BRICK_W) - (ballX - BALL_R);
          float oT = (ballY + BALL_R) - by, oB = (by + BRICK_H) - (ballY - BALL_R);
          if (min(oL, oR) < min(oT, oB)) ballVx = -ballVx;
          else                            ballVy = -ballVy;
          score += (BRICK_ROWS - r) * 10 * level;
          // Flag the record only; the sketch commits it on exit or game over.
          if (score > highScores[selectedGame][(int)currentDiff]) newRecord = true;
          goto done_bricks;
        }
      }
    }
    done_bricks:;

    if (bricksRemaining() == 0) {
      level++; sfxLevelUp();
      initBricks();
      float spd = sqrtf(ballVx * ballVx + ballVy * ballVy) * 1.1f;
      if (spd > 4.0f) spd = 4.0f;
      float ang = atan2f(ballVy, ballVx);
      ballVx = cosf(ang) * spd;
      ballVy = sinf(ang) * spd;
    }
  }

  void draw() {
    display.clearDisplay();
    display.setTextColor(SSD1306_WHITE);
    display.setTextSize(1);
    display.setCursor(0, 0);  display.print("S:"); display.print(score);
    display.setCursor(PLAY_W / 2 - 4, 0); display.print("L:"); display.print(lives);
    display.setCursor(PLAY_W - 18, 0); display.print("W:"); display.print(level);
    display.drawLine(0, 8, PLAY_W - 1, 8, SSD1306_WHITE);

    for (int r = 0; r < BRICK_ROWS; r++) {
      for (int c = 0; c < BRICK_COLS; c++) {
        if (!bricks[r][c]) continue;
        int bx = BRICK_XOFF + c * BRICK_W + 1;
        int by = BRICK_YOFF + r * BRICK_H + 1;
        if (r % 2 == 0) display.fillRect(bx, by, BRICK_W - 2, BRICK_H - 2, SSD1306_WHITE);
        else            display.drawRect(bx, by, BRICK_W - 2, BRICK_H - 2, SSD1306_WHITE);
      }
    }

    display.fillCircle((int)ballX, (int)ballY, BALL_R, SSD1306_WHITE);
    display.fillRoundRect(paddleX, PADDLE_Y, PADDLE_W, PADDLE_H, 1, SSD1306_WHITE);
    if (!ballLaunched) drawCenteredText(PLAY_H - 18, "A = LAUNCH", 1);
    display.display();
  }

  // ══════════════════════════════════════════════════════════
  //  SAVE SLOT  (optional contract — see SAVE_SYSTEM.md)
  //  Bricks pack to one bit each: 6 rows x 12 cols = 12 bytes.
  //  The ball comes back un-launched so you get a clean re-entry.
  // ══════════════════════════════════════════════════════════
  static const char* SAVE_TAG  = "ARKNOID";
  static constexpr uint8_t BLOB_VER = 1;

  struct SaveBlob {
    SaveHead h;
    int32_t  score;
    int16_t  lives, level;
    uint8_t  rows, cols, spare2[2];
    uint16_t rowBits[MAX_ROWS];
  };

  size_t captureState(void* out, size_t max) {
    if (!out || max < sizeof(SaveBlob)) return 0;
    if (BRICK_ROWS <= 0 || BRICK_ROWS > MAX_ROWS) return 0;
    if (BRICK_COLS <= 0 || BRICK_COLS > MAX_COLS) return 0;

    SaveBlob b; memset(&b, 0, sizeof(b));
    saveHeadFill(b.h, BLOB_VER, sizeof(SaveBlob));
    b.score = score;
    b.lives = (int16_t)lives;
    b.level = (int16_t)level;
    b.rows  = (uint8_t)BRICK_ROWS;
    b.cols  = (uint8_t)BRICK_COLS;
    for (int r = 0; r < BRICK_ROWS; r++)
      for (int c = 0; c < BRICK_COLS; c++)
        if (bricks[r][c]) b.rowBits[r] |= (uint16_t)(1u << c);
    memcpy(out, &b, sizeof(b));
    return sizeof(b);
  }

  bool restoreState(const void* in, size_t len) {
    if (!in || len < sizeof(SaveBlob)) return false;
    SaveBlob b; memcpy(&b, in, sizeof(b));
    if (!saveHeadOk(b.h, BLOB_VER, sizeof(SaveBlob))) return false;

    init();     // brick grid depends on PLAY_W *and* the selected difficulty
    if (b.rows != (uint8_t)BRICK_ROWS || b.cols != (uint8_t)BRICK_COLS) return false;

    for (int r = 0; r < BRICK_ROWS; r++)
      for (int c = 0; c < BRICK_COLS; c++)
        bricks[r][c] = ((b.rowBits[r] >> c) & 1) != 0;

    score = (b.score < 0) ? 0 : b.score;
    lives = constrain((int)b.lives, 1, 9);
    level = constrain((int)b.level, 1, 999);
    // A saved board with zero bricks left would instantly wave-clear on the
    // first frame. Harmless, but refilling is the sane resume.
    if (bricksRemaining() == 0) initBricks();
    resetBall();                    // reads level for ball speed — set it first
    return true;
  }

  void saveLabel(char* out, size_t n) {
    if (!out || n == 0) return;
    snprintf(out, n, "Wave%d  %d pts", level, score);
  }

  bool isOver()      { return gameOver; }
  int  getScore()    { return score; }
  bool isNewRecord() { return newRecord; }
}
