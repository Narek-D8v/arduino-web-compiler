# GLASER OS — ESP32-2432S028

A starter custom touchscreen firmware for the classic ESP32-2432S028 (CYD) board.

## Hardware assumptions
- ESP32-WROOM-32 / classic ESP32
- 2.8-inch 240x320 ILI9341 LCD
- XPT2046 resistive touch controller
- LCD pins: MISO 12, MOSI 13, SCLK 14, CS 15, DC 2, backlight 21
- Touch pins: SCLK 25, MISO 39, MOSI 32, CS 33, IRQ 36

Some board revisions differ. Check the board marking and screen controller before flashing.

## Build a flashable firmware BIN
1. Install Visual Studio Code and PlatformIO, or install PlatformIO Core.
2. Open this folder as a PlatformIO project.
3. Run `pio run`.
4. Firmware output should be ` .pio/build/glaser_os_esp32_2432s028/firmware.bin`.
5. Use ESP Web Tools only if you provide a valid manifest and matching flash layout. A raw `firmware.bin` is not necessarily a complete Web Tools installer by itself.

## Important notes
- This source has not been compiled or tested on physical hardware in this environment.
- Touch raw-coordinate calibration is approximate and likely needs adjustment for your panel.
- The project currently provides a basic home screen, system information, network status, and about page. It does not yet connect to Wi-Fi.
- To build a Web Tools installer, compile the firmware and then create a manifest with the correct chip family and flash offsets. Do not guess offsets; use the build output / esptool-generated flash layout.
