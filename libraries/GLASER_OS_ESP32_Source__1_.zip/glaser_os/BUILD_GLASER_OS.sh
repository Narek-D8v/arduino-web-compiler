#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: Python 3 is required. Install it, then run this script again."
  exit 1
fi

if ! command -v unzip >/dev/null 2>&1; then
  echo "ERROR: unzip is required. Install it, then run this script again."
  exit 1
fi

if [ ! -d .venv ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate
python -m pip install --upgrade pip platformio
pio run -e glaser_os_esp32_2432s028

OUT=".pio/build/glaser_os_esp32_2432s028/firmware.bin"
if [ ! -s "$OUT" ]; then
  echo "ERROR: Build did not produce $OUT"
  exit 1
fi
cp "$OUT" ./GLASER_OS_ESP32_2432S028.bin
echo
echo "SUCCESS: Firmware binary created at: $(pwd)/GLASER_OS_ESP32_2432S028.bin"
echo "This is a raw firmware image. ESP Web Tools may also require a manifest and the correct flash offsets."
