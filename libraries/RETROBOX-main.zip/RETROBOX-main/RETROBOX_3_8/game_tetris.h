// ============================================================
//  game_tetris.h  —  RETROBOX built-in game
//  Tetris — falling tetrominoes, line clears, levels
// ============================================================
#pragma once
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Preferences.h>
#include <math.h>
#include "retrobox_types.h"
#include "save_system.h"

extern Adafruit_SSD1306 display;
extern Preferences       prefs;
extern int  PLAY_W, PLAY_H;
extern int  highScores[][3];
extern int  selectedGame;
extern Difficulty currentDiff;
extern bool joyLeft(), joyRight(), joyUp(), joyDown();
extern int  joyMoveStep();
extern Button btnA, btnB, btnStart, btnJoySW;
extern void sfxBeep(), sfxConfirm(), sfxBack(), sfxShoot();
extern void sfxExplode(), sfxGameOver(), sfxLevelUp(), sfxMenu(), sfxHit();
extern void saveScore(int game, int diff, int score);
extern void drawCenteredText(int y, const char* str, int size);
extern void scrollStarsV(int* sx, int* sy, int n, int speed);
extern void drawShip(int x, int y);

namespace TetrisGame {
  static const int MAX_W_CELLS = 10;   // the board is always 10 wide
  static const int MAX_H_CELLS = 20;   // and never taller than 20

  static int BOARD_W_CELLS, BOARD_H_CELLS, BLOCK, BOARD_X;
  static uint8_t* board = nullptr;
  static int  score, lives, level, lines;
  static bool gameOver, newRecord;

  static const int8_t PIECES[7][4][4][2] = {
    {{{0,1},{1,1},{2,1},{3,1}},{{2,0},{2,1},{2,2},{2,3}},{{0,2},{1,2},{2,2},{3,2}},{{1,0},{1,1},{1,2},{1,3}}},
    {{{1,0},{2,0},{1,1},{2,1}},{{1,0},{2,0},{1,1},{2,1}},{{1,0},{2,0},{1,1},{2,1}},{{1,0},{2,0},{1,1},{2,1}}},
    {{{1,0},{0,1},{1,1},{2,1}},{{1,0},{1,1},{2,1},{1,2}},{{0,1},{1,1},{2,1},{1,2}},{{1,0},{0,1},{1,1},{1,2}}},
    {{{1,0},{2,0},{0,1},{1,1}},{{1,0},{1,1},{2,1},{2,2}},{{1,1},{2,1},{0,2},{1,2}},{{0,0},{0,1},{1,1},{1,2}}},
    {{{0,0},{1,0},{1,1},{2,1}},{{2,0},{1,1},{2,1},{1,2}},{{0,1},{1,1},{1,2},{2,2}},{{1,0},{0,1},{1,1},{0,2}}},
    {{{0,0},{0,1},{1,1},{2,1}},{{1,0},{2,0},{1,1},{1,2}},{{0,1},{1,1},{2,1},{2,2}},{{1,0},{1,1},{0,2},{1,2}}},
    {{{2,0},{0,1},{1,1},{2,1}},{{1,0},{1,1},{1,2},{2,2}},{{0,1},{1,1},{2,1},{0,2}},{{0,0},{1,0},{1,1},{1,2}}}
  };

  static int  pieceType, pieceRot, pieceX, pieceY;
  static int  nextType;
  static unsigned long lastDrop, dropInterval;
  static bool leftHeld, rightHeld;
  static unsigned long leftHeldAt, rightHeldAt;

  bool fits(int type, int rot, int px, int py) {
    // board can be null if calloc() failed. Reporting "nothing fits" makes
    // newPiece() end the run cleanly instead of dereferencing null and
    // panicking the ESP32.
    if (!board) return false;
    for (int b = 0; b < 4; b++) {
      int x = px + PIECES[type][rot][b][0];
      int y = py + PIECES[type][rot][b][1];
      if (x < 0 || x >= BOARD_W_CELLS || y >= BOARD_H_CELLS) return false;
      if (y >= 0 && board[y * BOARD_W_CELLS + x]) return false;
    }
    return true;
  }

  void newPiece() {
    pieceType = nextType;
    nextType  = random(0, 7);
    pieceRot  = 0;
    pieceX    = BOARD_W_CELLS / 2 - 2;
    pieceY    = -1;
    if (!fits(pieceType, pieceRot, pieceX, pieceY)) {
      gameOver = true; sfxGameOver();
    }
  }

  void lockPiece() {
    if (!board) return;
    for (int b = 0; b < 4; b++) {
      int x = pieceX + PIECES[pieceType][pieceRot][b][0];
      int y = pieceY + PIECES[pieceType][pieceRot][b][1];
      if (y >= 0 && y < BOARD_H_CELLS && x >= 0 && x < BOARD_W_CELLS)
        board[y * BOARD_W_CELLS + x] = pieceType + 1;
    }
    int cleared = 0;
    for (int row = BOARD_H_CELLS - 1; row >= 0; row--) {
      bool full = true;
      for (int c = 0; c < BOARD_W_CELLS; c++) if (!board[row * BOARD_W_CELLS + c]) { full = false; break; }
      if (full) {
        cleared++;
        for (int r = row; r > 0; r--)
          for (int c = 0; c < BOARD_W_CELLS; c++)
            board[r * BOARD_W_CELLS + c] = board[(r-1) * BOARD_W_CELLS + c];
        for (int c = 0; c < BOARD_W_CELLS; c++) board[c] = 0;
        row++;
      }
    }
    if (cleared > 0) {
      sfxLevelUp();
      static const int pts[] = {0, 100, 300, 500, 800};
      score += pts[min(cleared, 4)] * level;
      lines += cleared;
      level = 1 + lines / 10;
      unsigned long minDrop = (currentDiff == DIFF_EASY) ? 200UL : (currentDiff == DIFF_HARD) ? 80UL : 120UL;
      dropInterval = max(minDrop, (unsigned long)(800 - level * 40));
      // Flag the record only; the sketch commits it on exit or game over.
      if (score > highScores[selectedGame][(int)currentDiff]) newRecord = true;
    }
    newPiece();
  }

  void init() {
    BLOCK = (PLAY_W < 80) ? 5 : 4;
    BOARD_W_CELLS = MAX_W_CELLS;
    int boardPixH = PLAY_H;
    BOARD_H_CELLS = boardPixH / BLOCK;
    if (BOARD_H_CELLS > MAX_H_CELLS) BOARD_H_CELLS = MAX_H_CELLS;
    if (BOARD_H_CELLS < 6)           BOARD_H_CELLS = 6;
    BOARD_X = 2;

    if (board) { free(board); board = nullptr; }
    board = (uint8_t*)calloc(BOARD_W_CELLS * BOARD_H_CELLS, 1);

    score = 0; lives = 0; level = 1; lines = 0;
    gameOver = false; newRecord = false;
    dropInterval = (currentDiff == DIFF_EASY) ? 800UL : (currentDiff == DIFF_HARD) ? 400UL : 600UL;
    nextType = random(0, 7);
    newPiece();          // sets gameOver if the allocation failed
    lastDrop = millis();
    leftHeld = rightHeld = false;
  }

  void update() {
    if (gameOver) return;
    if (!board) return;
    if (joyLeft()) {
      if (!leftHeld) { leftHeld = true; leftHeldAt = millis(); if (fits(pieceType, pieceRot, pieceX - 1, pieceY)) { pieceX--; sfxMenu(); } }
      else if (millis() - leftHeldAt > 280) { if (fits(pieceType, pieceRot, pieceX - 1, pieceY)) pieceX--; }
    } else leftHeld = false;
    if (joyRight()) {
      if (!rightHeld) { rightHeld = true; rightHeldAt = millis(); if (fits(pieceType, pieceRot, pieceX + 1, pieceY)) { pieceX++; sfxMenu(); } }
      else if (millis() - rightHeldAt > 280) { if (fits(pieceType, pieceRot, pieceX + 1, pieceY)) pieceX++; }
    } else rightHeld = false;
    if (btnA.pressed) {
      int nr = (pieceRot + 1) % 4;
      if (fits(pieceType, nr, pieceX, pieceY)) { pieceRot = nr; sfxBeep(); }
    }
    unsigned long interval = joyDown() ? 60 : dropInterval;
    if (millis() - lastDrop > interval) {
      lastDrop = millis();
      if (fits(pieceType, pieceRot, pieceX, pieceY + 1)) pieceY++;
      else lockPiece();
    }
  }

  void draw() {
    display.clearDisplay();
    display.setTextColor(SSD1306_WHITE);
    display.setTextSize(1);
    if (!board) { drawCenteredText(PLAY_H / 2 - 4, "NO MEMORY", 1); display.display(); return; }

    int hx = BOARD_X + BOARD_W_CELLS * BLOCK + 4;
    if (hx + 20 < PLAY_W) {
      display.setCursor(hx, 0);  display.print("NXT");
      for (int b = 0; b < 4; b++) {
        int px = hx + PIECES[nextType][0][b][0] * 3;
        int py = 9  + PIECES[nextType][0][b][1] * 3;
        display.fillRect(px, py, 2, 2, SSD1306_WHITE);
      }
      display.setCursor(hx, 24); display.print("LV");
      display.setCursor(hx, 32); display.print(level);
      display.setCursor(hx, 42); display.print("SC");
      display.setCursor(hx, 50); display.print(score / 100);
    }

    display.drawRect(BOARD_X - 1, 0, BOARD_W_CELLS * BLOCK + 2, BOARD_H_CELLS * BLOCK + 1, SSD1306_WHITE);
    for (int r = 0; r < BOARD_H_CELLS; r++)
      for (int c = 0; c < BOARD_W_CELLS; c++)
        if (board[r * BOARD_W_CELLS + c])
          display.fillRect(BOARD_X + c * BLOCK, r * BLOCK, BLOCK - 1, BLOCK - 1, SSD1306_WHITE);

    for (int b = 0; b < 4; b++) {
      int x = pieceX + PIECES[pieceType][pieceRot][b][0];
      int y = pieceY + PIECES[pieceType][pieceRot][b][1];
      if (y >= 0)
        display.fillRect(BOARD_X + x * BLOCK, y * BLOCK, BLOCK - 1, BLOCK - 1, SSD1306_WHITE);
    }

    int gy = pieceY;
    while (fits(pieceType, pieceRot, pieceX, gy + 1)) gy++;
    if (gy != pieceY) {
      for (int b = 0; b < 4; b++) {
        int x = pieceX + PIECES[pieceType][pieceRot][b][0];
        int y = gy + PIECES[pieceType][pieceRot][b][1];
        if (y >= 0)
          display.drawRect(BOARD_X + x * BLOCK, y * BLOCK, BLOCK - 1, BLOCK - 1, SSD1306_WHITE);
      }
    }
    display.display();
  }

  // ══════════════════════════════════════════════════════════
  //  SAVE SLOT  (optional contract — see SAVE_SYSTEM.md)
  //  The stack IS the progress, so the whole board goes in.
  //  10 x 20 = 200 bytes, the largest blob in the firmware.
  // ══════════════════════════════════════════════════════════
  static const char* SAVE_TAG  = "TETRIS";
  static constexpr uint8_t BLOB_VER = 1;

  struct SaveBlob {
    SaveHead h;
    int32_t  score;
    uint32_t dropInterval;
    int16_t  level, lines;
    int16_t  bw, bh;
    uint8_t  nextType, spare2[3];
    uint8_t  cells[MAX_W_CELLS * MAX_H_CELLS];
  };

  size_t captureState(void* out, size_t max) {
    if (!out || max < sizeof(SaveBlob)) return 0;
    if (!board) return 0;
    if (BOARD_W_CELLS <= 0 || BOARD_H_CELLS <= 0) return 0;
    if (BOARD_W_CELLS * BOARD_H_CELLS > MAX_W_CELLS * MAX_H_CELLS) return 0;

    SaveBlob b; memset(&b, 0, sizeof(b));
    saveHeadFill(b.h, BLOB_VER, sizeof(SaveBlob));
    b.score        = score;
    b.dropInterval = (uint32_t)dropInterval;
    b.level        = (int16_t)level;
    b.lines        = (int16_t)lines;
    b.bw           = (int16_t)BOARD_W_CELLS;
    b.bh           = (int16_t)BOARD_H_CELLS;
    b.nextType     = (uint8_t)nextType;
    memcpy(b.cells, board, (size_t)BOARD_W_CELLS * BOARD_H_CELLS);
    memcpy(out, &b, sizeof(b));
    return sizeof(b);
  }

  bool restoreState(const void* in, size_t len) {
    if (!in || len < sizeof(SaveBlob)) return false;
    SaveBlob b; memcpy(&b, in, sizeof(b));
    if (!saveHeadOk(b.h, BLOB_VER, sizeof(SaveBlob))) return false;

    init();                                   // allocates the board at the right size
    if (!board) return false;
    if (b.bw != (int16_t)BOARD_W_CELLS || b.bh != (int16_t)BOARD_H_CELLS) return false;
    if (b.bw <= 0 || b.bh <= 0) return false;
    if ((int)b.bw * (int)b.bh > MAX_W_CELLS * MAX_H_CELLS) return false;

    memcpy(board, b.cells, (size_t)b.bw * b.bh);
    // Clamp every cell to a valid piece id so a flipped bit can't index
    // outside PIECES[] anywhere downstream.
    for (int i = 0; i < b.bw * b.bh; i++) if (board[i] > 7) board[i] = 1;

    score        = (b.score < 0) ? 0 : b.score;
    level        = constrain((int)b.level, 1, 999);
    lines        = (b.lines < 0) ? 0 : b.lines;
    dropInterval = constrain((unsigned long)b.dropInterval, 60UL, 900UL);
    nextType     = b.nextType % 7;
    newPiece();                               // sets gameOver if the stack is topped out
    lastDrop     = millis();
    return true;
  }

  void saveLabel(char* out, size_t n) {
    if (!out || n == 0) return;
    snprintf(out, n, "Lv%d  %d pts", level, score);
  }

  bool isOver()      { return gameOver; }
  int  getScore()    { return score; }
  bool isNewRecord() { return newRecord; }
}
