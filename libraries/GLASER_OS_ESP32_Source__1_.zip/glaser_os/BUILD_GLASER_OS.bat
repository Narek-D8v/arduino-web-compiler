@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo ERROR: Install Python 3 from https://www.python.org/downloads/ and select Add Python to PATH.
  pause
  exit /b 1
)
if not exist .venv py -3 -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip platformio
if errorlevel 1 goto :fail
pio run -e glaser_os_esp32_2432s028
if errorlevel 1 goto :fail
copy /y .pio\build\glaser_os_esp32_2432s028\firmware.bin GLASER_OS_ESP32_2432S028.bin >nul
if errorlevel 1 goto :fail
echo.
echo SUCCESS: GLASER_OS_ESP32_2432S028.bin created in this folder.
echo This is a raw firmware image. ESP Web Tools may also require a manifest and correct flash offsets.
pause
exit /b 0
:fail
echo.
echo BUILD FAILED. Read the errors above; check your internet connection and board configuration.
pause
exit /b 1
