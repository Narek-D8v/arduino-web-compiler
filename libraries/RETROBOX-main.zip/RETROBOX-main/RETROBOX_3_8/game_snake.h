// ============================================================
//  game_snake.h  —  RETROBOX built-in game
//  Snake — grow, 3 lives, speed increases
// ============================================================
#pragma once
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Preferences.h>
#include <math.h>
#include "retrobox_types.h"
#include "save_system.h"

extern Adafruit_SSD1306 display;
extern Preferences       prefs;
extern int  PLAY_W, PLAY_H;
extern int  highScores[][3];
extern int  selectedGame;
extern Difficulty currentDiff;
extern bool joyLeft(), joyRight(), joyUp(), joyDown();
extern int  joyMoveStep();
extern Button btnA, btnB, btnStart, btnJoySW;
extern void sfxBeep(), sfxConfirm(), sfxBack(), sfxShoot();
extern void sfxExplode(), sfxGameOver(), sfxLevelUp(), sfxMenu(), sfxHit();
extern void saveScore(int game, int diff, int score);
extern void drawCenteredText(int y, const char* str, int size);
extern void scrollStarsV(int* sx, int* sy, int n, int speed);
extern void drawShip(int x, int y);

namespace SnakeGame {
  static const int CELL = 4;
  static int COLS, ROWS;
  static const int HUD_H = 10;
  static const int MAX_LEN = 512;

  struct Pt { int16_t x, y; };
  static Pt   snake[MAX_LEN];
  static int  snakeLen;
  static Pt   food;
  static int  dx, dy;
  // Queued turn. This used to be `static int ndx, ndy` INSIDE update(),
  // which meant it survived init() — restart after dying while heading up
  // and the fresh snake immediately turned up instead of right.
  static int  nextDx, nextDy;
  static int  score, level, lives;
  static bool gameOver, newRecord;
  static unsigned long lastMove;
  static int  moveInterval;

  void placeFood() {
    if (COLS <= 0 || ROWS <= 0) return;
    // Bounded search, then a linear sweep. The old while(!ok) loop could spin
    // forever once the snake filled the board.
    for (int tries = 0; tries < 200; tries++) {
      food.x = random(0, COLS);
      food.y = random(0, ROWS);
      bool clash = false;
      for (int i = 0; i < snakeLen; i++)
        if (snake[i].x == food.x && snake[i].y == food.y) { clash = true; break; }
      if (!clash) return;
    }
    for (int y = 0; y < ROWS; y++)
      for (int x = 0; x < COLS; x++) {
        bool clash = false;
        for (int i = 0; i < snakeLen; i++)
          if (snake[i].x == x && snake[i].y == y) { clash = true; break; }
        if (!clash) { food.x = (int16_t)x; food.y = (int16_t)y; return; }
      }
    food.x = -1; food.y = -1;   // board completely full — unreachable food
  }

  void init() {
    COLS = PLAY_W / CELL;
    ROWS = (PLAY_H - HUD_H) / CELL;
    if (COLS < 4) COLS = 4;
    if (ROWS < 4) ROWS = 4;
    snakeLen = 3;
    dx = 1; dy = 0;
    nextDx = 1; nextDy = 0;
    int mx = COLS / 2, my = ROWS / 2;
    for (int i = 0; i < snakeLen; i++) snake[i] = {(int16_t)(mx - i), (int16_t)my};
    score = 0; level = 1; lives = 3;
    gameOver = false; newRecord = false;
    moveInterval = (currentDiff == DIFF_EASY) ? 200 : (currentDiff == DIFF_HARD) ? 100 : 150;
    placeFood();
    lastMove = millis();
  }

  void update() {
    if (gameOver) return;
    if (joyLeft()  && dx ==  0) { nextDx = -1; nextDy =  0; }
    if (joyRight() && dx ==  0) { nextDx =  1; nextDy =  0; }
    if (joyUp()    && dy ==  0) { nextDx =  0; nextDy = -1; }
    if (joyDown()  && dy ==  0) { nextDx =  0; nextDy =  1; }

    if (millis() - lastMove < (unsigned long)moveInterval) return;
    lastMove = millis();
    dx = nextDx; dy = nextDy;

    Pt head = {(int16_t)(snake[0].x + dx), (int16_t)(snake[0].y + dy)};
    bool wallHit = head.x < 0 || head.x >= COLS || head.y < 0 || head.y >= ROWS;
    bool selfHit = false;
    for (int i = 0; i < snakeLen - 1; i++)
      if (snake[i].x == head.x && snake[i].y == head.y) { selfHit = true; break; }

    if (wallHit || selfHit) {
      sfxExplode();
      lives--;
      if (lives <= 0) { gameOver = true; sfxGameOver(); return; }
      snakeLen = 3;
      int mx = COLS / 2, my = ROWS / 2;
      for (int i = 0; i < snakeLen; i++) snake[i] = {(int16_t)(mx - i), (int16_t)my};
      dx = 1; dy = 0; nextDx = 1; nextDy = 0;
      placeFood();
      return;
    }

    for (int i = snakeLen - 1; i > 0; i--) snake[i] = snake[i-1];
    snake[0] = head;

    if (head.x == food.x && head.y == food.y) {
      if (snakeLen < MAX_LEN) snakeLen++;
      score += 10;
      sfxBeep();
      if (snakeLen % 5 == 0) {
        level++;
        moveInterval = max(60, (int)(moveInterval * 0.88f));
        sfxLevelUp();
      }
      // Flag the record only. Calling saveScore() here erased a flash page on
      // every single apple; the sketch commits it once, on exit or game over.
      if (score > highScores[selectedGame][(int)currentDiff]) newRecord = true;
      placeFood();
    }
  }

  void draw() {
    display.clearDisplay();
    display.setTextColor(SSD1306_WHITE);
    display.setTextSize(1);
    display.setCursor(0, 0); display.print("S:"); display.print(score);
    display.setCursor(PLAY_W - 28, 0); display.print("L:"); display.print(lives);
    display.drawLine(0, 8, PLAY_W - 1, 8, SSD1306_WHITE);

    for (int i = 0; i < snakeLen; i++) {
      int px = snake[i].x * CELL;
      int py = snake[i].y * CELL + HUD_H + 1;
      if (i == 0) display.fillRect(px, py, CELL - 1, CELL - 1, SSD1306_WHITE);
      else        display.drawRect(px, py, CELL - 1, CELL - 1, SSD1306_WHITE);
    }

    if (food.x >= 0) {
      int fx = food.x * CELL + 1, fy = food.y * CELL + HUD_H + 1;
      if ((millis() / 300) % 2 == 0) {
        display.fillRect(fx + 1, fy, CELL - 3, CELL - 1, SSD1306_WHITE);
        display.drawPixel(fx + 1, fy - 1, SSD1306_WHITE);
      } else {
        display.drawRect(fx, fy, CELL - 1, CELL - 1, SSD1306_WHITE);
      }
    }
    display.display();
  }

  // ══════════════════════════════════════════════════════════
  //  SAVE SLOT  (optional contract — see SAVE_SYSTEM.md)
  //  Every body segment sits exactly one cell from the one before
  //  it, so only the head needs real coordinates and each of the
  //  rest is 2 bits. A full 512-segment snake packs into 128 bytes.
  // ══════════════════════════════════════════════════════════
  static const char* SAVE_TAG  = "SNAKE";
  static constexpr uint8_t BLOB_VER = 1;

  struct SaveBlob {
    SaveHead head;
    int32_t  score;
    int16_t  level, lives, moveInterval, len;
    int8_t   hx, hy, dx, dy;
    uint8_t  dirs[128];          // 4 segments per byte
  };

  size_t captureState(void* out, size_t max) {
    if (!out || max < sizeof(SaveBlob)) return 0;
    int n = snakeLen;
    if (n < 1) return 0;
    if (n > MAX_LEN) n = MAX_LEN;

    SaveBlob b; memset(&b, 0, sizeof(b));
    saveHeadFill(b.head, BLOB_VER, sizeof(SaveBlob));
    b.score        = score;
    b.level        = (int16_t)level;
    b.lives        = (int16_t)lives;
    b.moveInterval = (int16_t)moveInterval;
    b.hx = (int8_t)snake[0].x;  b.hy = (int8_t)snake[0].y;
    b.dx = (int8_t)dx;          b.dy = (int8_t)dy;
    b.len = (int16_t)n;

    for (int i = 1; i < n; i++) {
      int ddx = snake[i].x - snake[i-1].x;
      int ddy = snake[i].y - snake[i-1].y;
      uint8_t code;
      if      (ddx == -1 && ddy ==  0) code = 0;
      else if (ddx ==  1 && ddy ==  0) code = 1;
      else if (ddx ==  0 && ddy == -1) code = 2;
      else if (ddx ==  0 && ddy ==  1) code = 3;
      else { b.len = (int16_t)i; break; }   // non-adjacent: keep the valid prefix
      b.dirs[(i - 1) >> 2] |= (uint8_t)(code << (((i - 1) & 3) * 2));
    }
    memcpy(out, &b, sizeof(b));
    return sizeof(b);
  }

  bool restoreState(const void* in, size_t len) {
    if (!in || len < sizeof(SaveBlob)) return false;
    SaveBlob b; memcpy(&b, in, sizeof(b));
    if (!saveHeadOk(b.head, BLOB_VER, sizeof(SaveBlob))) return false;

    init();                                  // sets COLS/ROWS from PLAY_W/PLAY_H
    if (b.hx < 0 || b.hx >= COLS || b.hy < 0 || b.hy >= ROWS) return false;

    int n = constrain((int)b.len, 1, MAX_LEN);
    snake[0] = { (int16_t)b.hx, (int16_t)b.hy };
    for (int i = 1; i < n; i++) {
      uint8_t code = (b.dirs[(i - 1) >> 2] >> (((i - 1) & 3) * 2)) & 3;
      int ddx = (code == 0) ? -1 : (code == 1) ? 1 : 0;
      int ddy = (code == 2) ? -1 : (code == 3) ? 1 : 0;
      int nx = snake[i-1].x + ddx, ny = snake[i-1].y + ddy;
      if (nx < 0 || nx >= COLS || ny < 0 || ny >= ROWS) { n = i; break; }
      snake[i] = { (int16_t)nx, (int16_t)ny };
    }
    snakeLen = n;

    dx = nextDx = constrain((int)b.dx, -1, 1);
    dy = nextDy = constrain((int)b.dy, -1, 1);
    if (dx == 0 && dy == 0) { dx = nextDx = 1; }   // never resume standing still

    score        = (b.score < 0) ? 0 : b.score;
    level        = constrain((int)b.level, 1, 999);
    lives        = constrain((int)b.lives, 1, 9);
    moveInterval = constrain((int)b.moveInterval, 60, 400);
    placeFood();
    lastMove     = millis();
    return true;
  }

  void saveLabel(char* out, size_t n) {
    if (!out || n == 0) return;
    snprintf(out, n, "Len%d  %d pts", snakeLen, score);
  }

  bool isOver()      { return gameOver; }
  int  getScore()    { return score; }
  bool isNewRecord() { return newRecord; }
}
