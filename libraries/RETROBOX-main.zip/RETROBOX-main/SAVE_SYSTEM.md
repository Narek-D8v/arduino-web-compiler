# RETROBOX Save System

> How save/continue works under the hood, and how to add it to a game you write.

Every RETROBOX game gets **one save slot**. Saving again overwrites that
slot. It costs a game nothing to skip this — the CONTINUE screen only
appears for games that implement it, and everything else works exactly as
before.

This file is the technical reference. If you just want to *play* the
save feature, see the "Saving & Continuing" section in `GAME_MANUAL.md`.
If you're adding a new game and want it to support saving, **Step 7 of
`ADDING_A_GAME.md`** is the quick path — come back here for the details
it points at.

---

## The split: engine vs. games

`save_system.h` is a **storage engine only**. It knows how to put a lump
of bytes in flash and get the same bytes back intact. It has never heard
of Tetris, Snake, or Mario — it just deals in `(gameId, tag, bytes)`.

Each game that wants saving supplies **three optional functions** inside
its own namespace, right alongside `init()`/`update()`/`draw()`:

```cpp
size_t captureState(void* out, size_t max);   // RAM  -> blob
bool   restoreState(const void* in, size_t len); // blob -> RAM
void   saveLabel(char* out, size_t n);           // one line for the CONTINUE screen
```

That's it. This keeps the modular theme intact — your game file is still
the only file that changes when you add a game, and a game that never
implements these three functions simply has no save. Nothing else in the
firmware needs to know or care.

---

## The contract, in full

### 1. Give your game a tag and a version

```cpp
static const char* SAVE_TAG  = "MYGAME";   // ≤ 7 chars, unique across all games
static constexpr uint8_t BLOB_VER = 1;     // bump this whenever SaveBlob's layout changes
```

The tag is stored *inside* every save alongside the game index. If someone
reorders the `GameID` enum later, a saved Tetris blob can never be handed
to Snake by accident — the tag simply won't match and the load is refused.

### 2. Define your blob as plain data

```cpp
struct SaveBlob {
  SaveHead h;              // ALWAYS first — see below
  int32_t  score;
  int16_t  level, lives;
  // ...whatever your game needs to resume
};
```

Rules that matter here:
- **Every field is POD** — fixed-width integers (`int32_t`, `uint8_t`,
  ...), fixed-size arrays, no pointers, no `String`, no STL containers.
  The whole struct gets `memcpy`'d to and from flash as raw bytes.
- **`SaveHead h` is always the first member.** It's 8 bytes and buys you
  three safety checks for free — see below.
- **Keep it small.** The shared buffer is `RB_SAVE_MAXBLOB` bytes
  (currently 320 — Tetris's full board is the biggest blob at 224).
  If your struct doesn't fit, either trim it or raise the constant in
  `save_system.h` (that costs one stack buffer's worth of RAM in the
  sketch, so raise it only as much as you need).
- **`memset` the whole struct to zero before filling it in.** This isn't
  about correctness — uninitialized padding bytes don't affect the
  fields you actually read back — but it keeps every save deterministic
  and makes the CRC verifiable from field values alone, which matters if
  you're ever debugging one by hand.

### 3. `SaveHead` — the guard rail every blob shares

```cpp
struct SaveHead {
  uint8_t  blobVer;
  uint8_t  pw, ph;      // PLAY_W / PLAY_H at save time
  uint8_t  spare;
  uint32_t blobSize;
};
```

Two calls do all the work:

```cpp
saveHeadFill(b.h, BLOB_VER, sizeof(SaveBlob));   // when capturing
saveHeadOk (b.h, BLOB_VER, sizeof(SaveBlob));    // when restoring — returns false to reject
```

`saveHeadOk` checks three things, and **rejecting is always safe** — a
`false` here just means "start a new game instead," never a crash:

| Check | Catches |
|---|---|
| `blobVer` matches | You changed `SaveBlob` and bumped the version — an old save from before the change is refused instead of misread field-by-field. |
| `blobSize` matches `sizeof(SaveBlob)` | You changed the struct's layout and **forgot** to bump `blobVer`. This is the one contributors actually forget, so it's checked independently. |
| `pw`/`ph` match current `PLAY_W`/`PLAY_H` | A save made in landscape can't be poured into a portrait board — geometry-dependent games (grid size, board dimensions) fail this cleanly instead of drawing corrupted state. |

### 4. Write `captureState` / `restoreState` / `saveLabel`

```cpp
size_t captureState(void* out, size_t max) {
  if (!out || max < sizeof(SaveBlob)) return 0;
  SaveBlob b; memset(&b, 0, sizeof(b));
  saveHeadFill(b.h, BLOB_VER, sizeof(SaveBlob));
  b.score = score;
  b.level = (int16_t)level;
  b.lives = (int16_t)lives;
  memcpy(out, &b, sizeof(b));
  return sizeof(b);
}

bool restoreState(const void* in, size_t len) {
  if (!in || len < sizeof(SaveBlob)) return false;
  SaveBlob b; memcpy(&b, in, sizeof(b));
  if (!saveHeadOk(b.h, BLOB_VER, sizeof(SaveBlob))) return false;

  init();                                    // ALWAYS call your own init() first
  score = (b.score < 0) ? 0 : b.score;       // then clamp and overwrite
  level = constrain((int)b.level, 1, 999);
  lives = constrain((int)b.lives, 1, 9);
  return true;
}

void saveLabel(char* out, size_t n) {
  if (!out || n == 0) return;
  snprintf(out, n, "Lv%d  %d pts", level, score);   // shown on the CONTINUE screen
}
```

**Always call `init()` at the top of `restoreState()`.** This guarantees
geometry, difficulty scaling, and any `malloc`'d buffers are set up
correctly before you overwrite the progress fields — you're never
restoring into half-initialized state. It's also why `restoreState()`
is safe to call speculatively: if it returns `false` partway through,
the game is still in the perfectly normal state that `init()` just left
it in.

**Clamp every field you restore.** A blob that passed the header check
can still contain a `lives` of `-40` if flash corrupted a single byte in
a way the CRC didn't happen to catch, or if a future version of your
own game writes a wider range than an older `restoreState()` expects.
`constrain()` everything against sane bounds rather than trusting the
number.

### 5. One line in the sketch

In `RETROBOX_3_8.ino`, find `gameSaveHooks()` and add your game:

```cpp
#ifdef ENABLE_MYGAME
    case GAME_MYGAME: return { MyGame::captureState, MyGame::restoreState,
                                MyGame::saveLabel,    MyGame::SAVE_TAG };
#endif
```

That's the only sketch-side change. Everything else — the CONTINUE
screen, the save-on-exit prompt, the dev-menu slot viewer, difficulty/
orientation pre-selection — reads through this one function and needs
no per-game code.

---

## Deciding *what* to save: exact vs. regenerate

Not everything worth resuming needs to be byte-exact. Four different
answers are already in the codebase — copy whichever shape fits your
game:

- **Exact, because the state IS the game** — Tetris (the whole board),
  Snake (the exact body), Arkanoid (the exact brick layout). If you
  regenerated these, you'd be handing the player a different game.
- **Exact, because it's cheap to reproduce** — DOOM stores an 8-way map
  *index*, not the map. The 8 maps are fixed data, so storing one byte
  reproduces the level exactly.
- **Progress only, fresh world** — Racer, V-Shooter. Score, lives,
  level, resources — the road/enemies restart clean because they were
  randomly generated anyway; nothing meaningful is lost.
- **Progress only, regenerated world** — Dungeon Crawler stores
  score/depth/HP/attack and rolls a **new floor at the same depth** on
  restore. Freezing the actual procedural map (tiles + fog + enemies)
  would cost roughly 600 bytes for a game whose whole premise is that
  the floor is different every time — not worth it.

If you're not sure which your game needs: ask whether a player would
feel cheated getting a *different* but equally-fair version of what
they saved. If not, regenerate it and save the bytes.

---

## The flash-wear rule

**Never call anything that writes to flash from inside your scoring
path.** This was a real bug found while building this system — every
built-in game used to call `saveScore()` (an NVS write) the instant a
new high score happened. In Racer, whose score recomputes every frame,
that meant roughly **1,800 flash erases per minute** during a record
run. ESP32 flash is rated for about 100,000 erase cycles — that's a
dead chip in under a day of play.

The fix, and the rule for any new game: set a `newRecord` flag in RAM
only. The sketch commits the score **once**, on game over or on
save-and-exit. Your `update()` should look like this:

```cpp
if (score > highScores[selectedGame][(int)currentDiff]) newRecord = true;
```

never this:

```cpp
if (score > highScores[selectedGame][(int)currentDiff]) {
  saveScore(selectedGame, (int)currentDiff, score);   // ← flash write on every point. Don't.
  newRecord = true;
}
```

The same logic applies to your own `captureState()`: it's already only
called when the player explicitly saves (pause → B → A) or the sketch
saves on their behalf on exit — never from inside `update()`.

---

## Safety properties (what the engine guarantees you)

These are enforced by `save_system.h` for every game automatically —
you don't need to implement any of this yourself:

- **CRC32 over the payload.** A corrupted or partially-written slot is
  detected and reads back as "no save," never as garbage state fed to
  your game.
- **Payload written before metadata.** If power is lost mid-save, the
  stale metadata won't match the new payload's CRC, so the load fails
  cleanly instead of pairing an old header with a new body (or vice
  versa).
- **Separate NVS namespace** (`rbsave`, vs. `rb24` for high scores) —
  wiping saves can never touch scores and vice versa.
- **Tag isolation** — covered above under `SAVE_TAG`.
- **A rejected load is always a safe fallback**, never a crash. Every
  `false`/`0` return from the engine or from your `restoreState()`
  results in the sketch quietly starting a normal new game.

All of this was verified with a Linux simulation harness covering all
8 games: round-trip saves at every difficulty, single-bit flash
corruption, truncated/foreign/wrong-version blobs, a simulated power
cycle, a simulated torn write, 48,000 fuzzed restores, and a 900,000-
frame random-input soak test of the whole state machine. If you're
contributing a game with save support and want to stress-test it the
same way before opening a PR, ask a maintainer — the harness isn't
checked into this repo yet, but it's straightforward to point at a new
game's three functions.

---

## Quick checklist for a new game

- [ ] `SAVE_TAG` — unique, ≤ 7 characters
- [ ] `BLOB_VER` — starts at 1, bump on every layout change
- [ ] `SaveBlob` — POD only, `SaveHead h` first, fits in `RB_SAVE_MAXBLOB`
- [ ] `captureState()` — `memset` then fill, returns `0` on any failure
- [ ] `restoreState()` — checks the header, calls `init()`, clamps every field
- [ ] `saveLabel()` — short, human-readable, fits `RB_SAVE_LABELLEN`
- [ ] One line added to `gameSaveHooks()` in the `.ino`, guarded by your
      game's `#ifdef`
- [ ] No flash-writing call anywhere in your scoring path
